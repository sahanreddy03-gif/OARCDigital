// Demo data and calculations for OARC Dashboard

export interface KPI {
  label: string
  value: string
  delta: number
  tooltip: string
}

export interface Problem {
  id: string
  title: string
  insight: string
  monthlyImpact: number
  psychology: string
  solutions: Solution[]
}

export interface Solution {
  title: string
  timeframe: string
  impact: string
}

export interface VerticalData {
  id: string
  name: string
  icon: string
  tagline: string
  problems: Problem[]
}

export const verticals: VerticalData[] = [
  {
    id: "restaurant",
    name: "Restaurant",
    icon: "🍽️",
    tagline: "Turn empty tables into revenue",
    problems: [
      {
        id: "ghost-reservations",
        title: "Ghost Reservations",
        insight:
          "Your staff prepares for guests who never arrive. Tables sit empty while walk-ins are turned away. The kitchen preps food that gets wasted.",
        monthlyImpact: 4200,
        psychology:
          "Customers book as a 'backup option' because canceling feels awkward. No reminder means out of sight, out of mind.",
        solutions: [
          { title: "Smart confirmation system", timeframe: "48 hours", impact: "65% fewer no-shows" },
          { title: "Instant waitlist backfill", timeframe: "Same day", impact: "Recover 80% of cancellations" },
          { title: "Reputation-based booking", timeframe: "2 weeks", impact: "Identify repeat offenders" },
        ],
      },
      {
        id: "kitchen-chaos",
        title: "Kitchen Chaos",
        insight:
          "Orders pile up during rush. Staff stress skyrockets. Mistakes multiply. Customers wait longer than promised.",
        monthlyImpact: 2800,
        psychology:
          "When overwhelmed, cooks default to tunnel vision. Communication breaks down. Pride prevents asking for help.",
        solutions: [
          { title: "Intelligent order pacing", timeframe: "3 days", impact: "40% faster ticket times" },
          { title: "Prep prediction engine", timeframe: "1 week", impact: "Cut prep waste by 35%" },
          { title: "Real-time bottleneck alerts", timeframe: "48 hours", impact: "Catch problems before they cascade" },
        ],
      },
      {
        id: "invisible-regulars",
        title: "Invisible Regulars",
        insight:
          "Your best customers come 3x per month. You treat them like first-timers. They feel unrecognized, eventually drift to competitors.",
        monthlyImpact: 3600,
        psychology:
          "Recognition triggers loyalty. Humans remember how you made them feel. Anonymity feels like rejection.",
        solutions: [
          { title: "Guest recognition system", timeframe: "5 days", impact: "28% higher repeat rate" },
          { title: "Preference memory", timeframe: "1 week", impact: "Personalized service at scale" },
          { title: "Milestone celebrations", timeframe: "48 hours", impact: "Turn regulars into advocates" },
        ],
      },
      {
        id: "review-silence",
        title: "Review Silence",
        insight:
          "Happy customers leave quietly. Only angry ones post reviews. Your online rating slowly sinks while service stays consistent.",
        monthlyImpact: 2100,
        psychology:
          "Satisfaction is passive. Frustration demands action. Without prompting, the vocal minority shapes perception.",
        solutions: [
          { title: "Post-visit feedback capture", timeframe: "24 hours", impact: "5x more positive reviews" },
          { title: "Issue interception", timeframe: "48 hours", impact: "Catch problems before they go public" },
          { title: "Reputation monitoring", timeframe: "Same day", impact: "Real-time sentiment tracking" },
        ],
      },
      {
        id: "staff-turnover-spiral",
        title: "Staff Turnover Spiral",
        insight:
          "Good servers leave for competitors. Training new hires costs time and quality. Institutional knowledge walks out the door.",
        monthlyImpact: 3200,
        psychology:
          "Talented staff leave when they feel unvalued or see no growth. Schedule chaos signals disrespect for their time.",
        solutions: [
          { title: "Fair scheduling algorithm", timeframe: "3 days", impact: "40% better shift satisfaction" },
          { title: "Performance recognition", timeframe: "1 week", impact: "Surface hidden top performers" },
          { title: "Growth path visibility", timeframe: "2 weeks", impact: "Reduce turnover by 50%" },
        ],
      },
    ],
  },
  {
    id: "clinic",
    name: "Medical Clinic",
    icon: "🏥",
    tagline: "More patient time, less paperwork",
    problems: [
      {
        id: "appointment-chaos",
        title: "Appointment Chaos",
        insight:
          "Patients forget appointments. Your staff chases them by phone. Doctors sit idle while the waiting room overflows 30 minutes later.",
        monthlyImpact: 5100,
        psychology:
          "Medical appointments feel distant when booked. Life gets busy. A single SMS reminder at the right moment changes behavior.",
        solutions: [
          { title: "Multi-stage reminder sequence", timeframe: "48 hours", impact: "70% fewer no-shows" },
          { title: "Smart rescheduling", timeframe: "3 days", impact: "Fill 85% of cancelled slots" },
          { title: "Patient behavior scoring", timeframe: "1 week", impact: "Identify high-risk appointments" },
        ],
      },
      {
        id: "referral-black-hole",
        title: "Referral Black Hole",
        insight:
          "You refer patients to specialists. They never book. Their condition worsens. They return frustrated, wondering why you didn't follow up.",
        monthlyImpact: 3800,
        psychology:
          "Patients feel overwhelmed after appointments. Good intentions evaporate without immediate action. They assume you'll track it.",
        solutions: [
          { title: "Instant referral booking", timeframe: "5 days", impact: "3x referral completion" },
          { title: "Patient journey tracking", timeframe: "1 week", impact: "Close the feedback loop" },
          { title: "Specialist network sync", timeframe: "2 weeks", impact: "Real-time availability" },
        ],
      },
      {
        id: "phone-tag-marathon",
        title: "Phone Tag Marathon",
        insight:
          "Staff spend hours playing phone tag for routine updates. Patients can't reach you when they need to. Everyone's frustrated.",
        monthlyImpact: 2900,
        psychology:
          "Phone calls feel urgent but are inefficient. Both parties need to be available simultaneously. Async communication respects time.",
        solutions: [
          { title: "Secure patient messaging", timeframe: "3 days", impact: "60% fewer phone calls" },
          { title: "Automated result notifications", timeframe: "48 hours", impact: "Instant updates, no waiting" },
          { title: "Smart triage routing", timeframe: "1 week", impact: "Right message, right person" },
        ],
      },
      {
        id: "insurance-friction",
        title: "Insurance Friction",
        insight:
          "Claims rejected for data errors. Resubmissions take weeks. Cash flow suffers. Staff spend hours on preventable admin.",
        monthlyImpact: 4200,
        psychology:
          "Manual data entry under time pressure breeds errors. Staff learn to dread insurance work. Morale and accuracy both decline.",
        solutions: [
          { title: "Pre-submission validation", timeframe: "5 days", impact: "80% fewer rejections" },
          { title: "Auto-populated forms", timeframe: "1 week", impact: "90% less manual entry" },
          { title: "Claim status tracking", timeframe: "3 days", impact: "Proactive follow-up" },
        ],
      },
      {
        id: "patient-dropout",
        title: "Patient Dropout",
        insight:
          "Patients start treatment plans then disappear. Chronic conditions go unmanaged. They return only when problems escalate.",
        monthlyImpact: 3400,
        psychology:
          "Without accountability, patients optimize for short-term comfort. They need gentle nudges to maintain health habits.",
        solutions: [
          { title: "Treatment adherence tracking", timeframe: "1 week", impact: "45% better completion rates" },
          { title: "Personalized check-ins", timeframe: "48 hours", impact: "Patients feel cared for" },
          { title: "Early warning system", timeframe: "5 days", impact: "Catch dropouts before they disappear" },
        ],
      },
    ],
  },
  {
    id: "retail",
    name: "Retail",
    icon: "🛒",
    tagline: "Convert browsers into buyers",
    problems: [
      {
        id: "abandoned-treasure",
        title: "Abandoned Treasure",
        insight:
          "Customers fill carts with intent. Something interrupts them. They leave and forget. That cart represents real demand you're not capturing.",
        monthlyImpact: 6200,
        psychology:
          "Online shopping is impulsive. Interruptions reset mental state. A timely reminder reignites purchase intent before it fades.",
        solutions: [
          { title: "Smart recovery sequence", timeframe: "24 hours", impact: "Recover 15% of abandoned carts" },
          { title: "Exit intent capture", timeframe: "48 hours", impact: "Save customers before they leave" },
          { title: "Dynamic incentive engine", timeframe: "3 days", impact: "Personalized offers that convert" },
        ],
      },
      {
        id: "stock-blindspot",
        title: "Stock Blindspot",
        insight:
          "Your bestseller runs out. Customers see 'Out of Stock' and buy from competitors. By the time you restock, momentum is lost.",
        monthlyImpact: 4800,
        psychology:
          "Customers have low tolerance for unavailability. They won't wait. One stockout can permanently shift their habits.",
        solutions: [
          { title: "Predictive inventory alerts", timeframe: "3 days", impact: "Never miss a bestseller restock" },
          { title: "Demand forecasting", timeframe: "1 week", impact: "Order before you need it" },
          { title: "Back-in-stock automation", timeframe: "48 hours", impact: "Capture waiting demand" },
        ],
      },
      {
        id: "one-time-buyers",
        title: "One-Time Buyers",
        insight:
          "You spend to acquire customers. They buy once and vanish. You keep spending to replace them instead of nurturing existing ones.",
        monthlyImpact: 4100,
        psychology:
          "First purchases are experiments. Without follow-up, customers assume you only wanted your transaction, not your loyalty.",
        solutions: [
          { title: "Post-purchase nurture flow", timeframe: "48 hours", impact: "35% higher repeat rate" },
          { title: "Replenishment reminders", timeframe: "3 days", impact: "Perfectly timed reorders" },
          { title: "Loyalty program automation", timeframe: "1 week", impact: "Turn buyers into advocates" },
        ],
      },
      {
        id: "pricing-leaks",
        title: "Pricing Leaks",
        insight:
          "Manual promo codes stack incorrectly. Staff apply wrong discounts. You lose margin on sales that would've converted anyway.",
        monthlyImpact: 2900,
        psychology:
          "Customers test discount boundaries. Staff under pressure approve anything. Without guardrails, margin erodes invisibly.",
        solutions: [
          { title: "Intelligent promo rules", timeframe: "3 days", impact: "Zero invalid discount stacking" },
          { title: "Margin protection alerts", timeframe: "48 hours", impact: "Real-time profitability checks" },
          { title: "Dynamic pricing engine", timeframe: "2 weeks", impact: "Optimize for demand, not guesswork" },
        ],
      },
      {
        id: "support-overwhelm",
        title: "Support Overwhelm",
        insight:
          "Simple questions flood your inbox. Staff answer the same things repeatedly. Complex issues get buried. Response times balloon.",
        monthlyImpact: 2400,
        psychology:
          "Customers ask before searching. Each unanswered question feels personal. Delays trigger complaints that create more work.",
        solutions: [
          { title: "AI-powered instant answers", timeframe: "3 days", impact: "Resolve 60% without human touch" },
          { title: "Smart ticket routing", timeframe: "48 hours", impact: "Right question, right expert" },
          { title: "Proactive FAQ surfacing", timeframe: "1 week", impact: "Answer before they ask" },
        ],
      },
    ],
  },
  {
    id: "realestate",
    name: "Real Estate",
    icon: "🏠",
    tagline: "Close more deals, faster",
    problems: [
      {
        id: "lead-graveyard",
        title: "Lead Graveyard",
        insight:
          "Inquiries come in. You're showing a property. By the time you respond, they've moved on to faster agents.",
        monthlyImpact: 7200,
        psychology:
          "Property seekers contact multiple agents. First responder wins. Every hour of delay halves conversion probability.",
        solutions: [
          { title: "Instant lead response", timeframe: "24 hours", impact: "5x faster first contact" },
          { title: "AI qualification calls", timeframe: "3 days", impact: "Pre-screen while you work" },
          { title: "Smart lead scoring", timeframe: "1 week", impact: "Focus on buyers, not browsers" },
        ],
      },
      {
        id: "showing-chaos",
        title: "Showing Chaos",
        insight:
          "You drive across town. The viewer doesn't show. No call, no message. You've lost an hour and the chance to show to serious buyers.",
        monthlyImpact: 3600,
        psychology:
          "Property viewings feel non-committal to browsers. Without skin in the game, flaking is easy and guilt-free.",
        solutions: [
          { title: "Confirmation workflow", timeframe: "48 hours", impact: "70% fewer no-shows" },
          { title: "Smart scheduling", timeframe: "3 days", impact: "Cluster viewings by area" },
          { title: "Virtual pre-screening", timeframe: "1 week", impact: "Only meet serious prospects" },
        ],
      },
      {
        id: "follow-up-fog",
        title: "Follow-up Fog",
        insight: "You meet great prospects. Weeks pass. You meant to follow up but got busy. They bought elsewhere.",
        monthlyImpact: 5400,
        psychology:
          "Out of sight, out of mind works both ways. Without systematic follow-up, relationships fade. Whoever stays present wins.",
        solutions: [
          { title: "Automated nurture sequences", timeframe: "48 hours", impact: "Never forget a prospect" },
          { title: "Life event triggers", timeframe: "1 week", impact: "Reach out at perfect moments" },
          { title: "Relationship health scoring", timeframe: "5 days", impact: "See who needs attention" },
        ],
      },
      {
        id: "paperwork-purgatory",
        title: "Paperwork Purgatory",
        insight:
          "Deals die in paperwork. Documents get lost. Signatures delayed. By closing, everyone's exhausted and relationships strained.",
        monthlyImpact: 2800,
        psychology:
          "Admin work feels like punishment after the excitement of agreement. Energy drops. Momentum stalls. Buyers second-guess.",
        solutions: [
          { title: "Digital document flow", timeframe: "3 days", impact: "Sign anywhere, anytime" },
          { title: "Progress tracking", timeframe: "48 hours", impact: "Everyone sees deal status" },
          { title: "Deadline automation", timeframe: "5 days", impact: "Auto-nudge before things expire" },
        ],
      },
      {
        id: "market-blindness",
        title: "Market Blindness",
        insight:
          "You price properties by gut feel. Some sit too long. Others sell too fast (too cheap). You're leaving money on the table.",
        monthlyImpact: 4100,
        psychology:
          "Market intuition has limits. Cognitive biases skew estimates. Data reveals patterns invisible to even experienced agents.",
        solutions: [
          { title: "Comparable analysis engine", timeframe: "1 week", impact: "Price with precision" },
          { title: "Days-on-market predictor", timeframe: "5 days", impact: "Set realistic expectations" },
          { title: "Market pulse alerts", timeframe: "3 days", impact: "Know before competitors" },
        ],
      },
    ],
  },
  {
    id: "igaming",
    name: "iGaming",
    icon: "🎰",
    tagline: "Maximize player lifetime value",
    problems: [
      {
        id: "registration-dropoff",
        title: "Registration Dropoff Cliff",
        insight:
          "Players start registration excited. They see form fields. They leave. You lose 70% of signups before they finish.",
        monthlyImpact: 8900,
        psychology:
          "Every field multiplies friction. Players are impatient and suspicious. Long forms signal bureaucracy, not excitement.",
        solutions: [
          { title: "Progressive registration", timeframe: "2 days", impact: "55% higher completion rate" },
          { title: "Social auth integration", timeframe: "48 hours", impact: "One-click registration" },
          { title: "Gamified onboarding", timeframe: "1 week", impact: "Turn signup into first win" },
        ],
      },
      {
        id: "first-deposit-anxiety",
        title: "First Deposit Anxiety",
        insight:
          "Registered players don't deposit. They browse, then leave. Trust hasn't been established. First financial commitment feels risky.",
        monthlyImpact: 12400,
        psychology:
          "Money triggers loss aversion. New platforms feel unproven. Players need social proof and safety signals before committing.",
        solutions: [
          { title: "Risk-free first bet bonus", timeframe: "24 hours", impact: "3x deposit conversion" },
          { title: "Trust badge automation", timeframe: "3 days", impact: "Display licenses prominently" },
          { title: "Instant withdrawal proof", timeframe: "1 week", impact: "Show real payout examples" },
        ],
      },
      {
        id: "dormant-whales",
        title: "Dormant Whales",
        insight:
          "High-value players stop logging in. No warning. No intervention. By the time you notice, they're active on competitor sites.",
        monthlyImpact: 18700,
        psychology:
          "Whales expect VIP treatment. Generic emails feel insulting. Silence signals you don't value them. Competitors hunt actively.",
        solutions: [
          { title: "Behavioral anomaly detection", timeframe: "3 days", impact: "Catch churn signals early" },
          { title: "Personal account manager", timeframe: "48 hours", impact: "Human touch for top 5%" },
          { title: "Predictive offer engine", timeframe: "1 week", impact: "Custom incentives that convert" },
        ],
      },
      {
        id: "bonus-abuse-epidemic",
        title: "Bonus Abuse Epidemic",
        insight:
          "Professional bonus hunters drain margins. They exploit loopholes. Real players subsidize their profits. Your bonus budget bleeds.",
        monthlyImpact: 9200,
        psychology:
          "Arbitrage communities share exploits. Sophisticated players optimize for bonuses, not gameplay. They have no loyalty.",
        solutions: [
          { title: "Behavior pattern analysis", timeframe: "5 days", impact: "Identify abusers in real-time" },
          { title: "Dynamic bonus qualification", timeframe: "1 week", impact: "Reward real players only" },
          { title: "Cross-platform fraud detection", timeframe: "2 weeks", impact: "Block multi-accounting" },
        ],
      },
      {
        id: "payment-failure-blackhole",
        title: "Payment Failure Blackhole",
        insight:
          "Players try to deposit. Payment fails. They don't know why. No alternative offered. They leave frustrated, never return.",
        monthlyImpact: 6800,
        psychology:
          "Payment failures feel like rejection. Players blame you, not their bank. Without instant alternatives, momentum dies.",
        solutions: [
          { title: "Smart payment routing", timeframe: "3 days", impact: "Auto-try alternative methods" },
          { title: "Real-time failure recovery", timeframe: "48 hours", impact: "Instant alternative suggestions" },
          { title: "Regional payment optimization", timeframe: "1 week", impact: "Show methods that actually work" },
        ],
      },
      {
        id: "responsible-gaming-crisis",
        title: "Responsible Gaming Crisis",
        insight:
          "Problem gamblers spiral unchecked. Regulators notice. Fines loom. Your reputation takes hits. Compliance is reactive, not proactive.",
        monthlyImpact: 15300,
        psychology:
          "Addicted players hide behavior. Manual review catches problems too late. AI detects patterns humans miss.",
        solutions: [
          { title: "AI behavior monitoring", timeframe: "1 week", impact: "Catch problem patterns early" },
          { title: "Automatic cool-off triggers", timeframe: "5 days", impact: "Intervene before crisis" },
          { title: "Regulatory compliance automation", timeframe: "2 weeks", impact: "Bulletproof audit trails" },
        ],
      },
    ],
  },
  {
    id: "legal",
    name: "Legal",
    icon: "⚖️",
    tagline: "Win more cases, bill more hours",
    problems: [
      {
        id: "inquiry-to-client-gap",
        title: "Inquiry-to-Client Gap",
        insight:
          "Potential clients inquire. You're in court. They call competitors while you're unavailable. By the time you respond, they've hired someone else.",
        monthlyImpact: 14200,
        psychology:
          "Legal problems feel urgent. Anxiety drives immediate action. First responder signals availability and care.",
        solutions: [
          { title: "AI intake qualification", timeframe: "48 hours", impact: "Capture leads 24/7" },
          { title: "Instant scheduling automation", timeframe: "3 days", impact: "Book consultations immediately" },
          { title: "Practice area routing", timeframe: "1 week", impact: "Right inquiry, right attorney" },
        ],
      },
      {
        id: "billable-hour-leakage",
        title: "Billable Hour Leakage",
        insight:
          "Attorneys do work but forget to log it. Switching between tasks makes time tracking impossible. You bill 70% of actual work.",
        monthlyImpact: 22500,
        psychology:
          "Time tracking feels like admin overhead. Memory is unreliable. Attorneys round down to seem reasonable, losing thousands monthly.",
        solutions: [
          { title: "Automatic time capture", timeframe: "5 days", impact: "AI logs work in background" },
          { title: "Smart time suggestions", timeframe: "1 week", impact: "Fill gaps with ML predictions" },
          { title: "Task-based billing templates", timeframe: "3 days", impact: "Never miss common activities" },
        ],
      },
      {
        id: "document-chaos",
        title: "Document Chaos",
        insight:
          "Critical documents buried in email. Versions conflicted. Deadlines missed because filings weren't found. Associates spend hours searching.",
        monthlyImpact: 8600,
        psychology:
          "Legal work is document-heavy. Email is terrible for retrieval. Stress makes search harder. Junior staff afraid to ask twice.",
        solutions: [
          { title: "Unified document repository", timeframe: "1 week", impact: "One source of truth" },
          { title: "Version control automation", timeframe: "5 days", impact: "Never lose track of edits" },
          { title: "Smart document search", timeframe: "3 days", impact: "Find anything in seconds" },
        ],
      },
      {
        id: "client-update-vacuum",
        title: "Client Update Vacuum",
        insight:
          "Clients feel ignored between meetings. They call repeatedly for status. Staff interruptions kill productivity. Clients perceive abandonment.",
        monthlyImpact: 5400,
        psychology:
          "Silence breeds anxiety in legal clients. They catastrophize. Proactive updates build trust and reduce calls exponentially.",
        solutions: [
          {
            title: "Automated case milestone updates",
            timeframe: "48 hours",
            impact: "Keep clients informed automatically",
          },
          { title: "Client portal with real-time status", timeframe: "1 week", impact: "Self-service transparency" },
          { title: "Proactive communication triggers", timeframe: "5 days", impact: "Update before they ask" },
        ],
      },
      {
        id: "knowledge-silos",
        title: "Knowledge Silos",
        insight:
          "Senior partner has case knowledge in their head. They leave firm or retire. Institutional knowledge evaporates. Cases suffer.",
        monthlyImpact: 11200,
        psychology:
          "Experts hoard knowledge unconsciously. Sharing feels like work. Junior attorneys reinvent wheels. Firm value tied to individuals, not systems.",
        solutions: [
          { title: "Case knowledge extraction", timeframe: "2 weeks", impact: "Capture expertise systematically" },
          { title: "Precedent database automation", timeframe: "1 week", impact: "Surface relevant past work" },
          { title: "Collaborative case notes", timeframe: "5 days", impact: "Build institutional memory" },
        ],
      },
      {
        id: "deadline-russian-roulette",
        title: "Deadline Russian Roulette",
        insight:
          "Court deadlines tracked manually. Calendar conflicts overlooked. Missed filings lead to malpractice claims and disciplinary action.",
        monthlyImpact: 19800,
        psychology:
          "Human memory fails under complexity. Calendar apps don't understand legal rules. Stakes are career-ending. Anxiety is constant.",
        solutions: [
          { title: "Court rule automation", timeframe: "1 week", impact: "Calculate deadlines perfectly" },
          { title: "Conflict detection", timeframe: "5 days", impact: "Flag overlapping obligations" },
          { title: "Multi-level deadline alerts", timeframe: "3 days", impact: "Escalating reminders that work" },
        ],
      },
    ],
  },
  {
    id: "finance",
    name: "Finance",
    icon: "💼",
    tagline: "Accelerate growth, reduce risk",
    problems: [
      {
        id: "lead-qualification-blindness",
        title: "Lead Qualification Blindness",
        insight:
          "Advisors waste time on tire-kickers. Real prospects slip through. No system distinguishes browsers from buyers.",
        monthlyImpact: 16700,
        psychology:
          "Everyone claims urgency. Advisors optimize for politeness, not profitability. Without data, instinct fails.",
        solutions: [
          { title: "Behavioral lead scoring", timeframe: "1 week", impact: "Identify serious prospects instantly" },
          { title: "Asset verification automation", timeframe: "5 days", impact: "Qualify AUM before meetings" },
          { title: "Engagement intensity tracking", timeframe: "3 days", impact: "Priority routing for hot leads" },
        ],
      },
      {
        id: "compliance-nightmare",
        title: "Compliance Nightmare",
        insight:
          "Regulations change constantly. Manual tracking fails. Audits reveal gaps. Fines and reputational damage follow.",
        monthlyImpact: 28400,
        psychology:
          "Compliance feels like punishment, not protection. Staff do minimum required. Small gaps compound into systemic violations.",
        solutions: [
          { title: "Real-time regulatory monitoring", timeframe: "2 weeks", impact: "Stay ahead of changes" },
          { title: "Automated audit trail generation", timeframe: "1 week", impact: "Always audit-ready" },
          { title: "Risk assessment dashboard", timeframe: "5 days", impact: "Spot vulnerabilities early" },
        ],
      },
      {
        id: "client-portfolio-blindness",
        title: "Client Portfolio Blindness",
        insight:
          "Clients don't understand their holdings. They panic during volatility. Emergency calls flood during market dips. You're reactive, not proactive.",
        monthlyImpact: 9200,
        psychology:
          "Financial complexity breeds fear. Jargon alienates. Silence during downturns signals abandonment. Education prevents panic.",
        solutions: [
          { title: "Visual portfolio storytelling", timeframe: "1 week", impact: "Clients understand at a glance" },
          {
            title: "Proactive volatility communications",
            timeframe: "48 hours",
            impact: "Calm nerves before calls come",
          },
          { title: "Educational content automation", timeframe: "5 days", impact: "Right lesson, right moment" },
        ],
      },
      {
        id: "referral-wasteland",
        title: "Referral Wasteland",
        insight:
          "Happy clients would refer friends. You don't ask systematically. Referrals happen randomly. You're leaving growth on the table.",
        monthlyImpact: 13600,
        psychology:
          "People want to help but need prompting. Timing matters. Right after success, gratitude peaks. Wait too long, it fades.",
        solutions: [
          { title: "Milestone referral triggers", timeframe: "3 days", impact: "Ask when gratitude is highest" },
          { title: "Referral tracking system", timeframe: "1 week", impact: "Close the loop visibly" },
          { title: "Social proof automation", timeframe: "5 days", impact: "Make referring easy and rewarding" },
        ],
      },
      {
        id: "data-fragmentation",
        title: "Data Fragmentation",
        insight:
          "Client data scattered across systems. CRM, portfolio platform, tax software don't talk. Advisors manually reconcile. Errors multiply.",
        monthlyImpact: 7800,
        psychology:
          "Context switching kills productivity. Manual data entry breeds mistakes. Frustration compounds daily. Technology should unite, not fragment.",
        solutions: [
          { title: "System integration platform", timeframe: "2 weeks", impact: "Single source of truth" },
          { title: "Automated data synchronization", timeframe: "1 week", impact: "Real-time consistency" },
          { title: "Unified client dashboard", timeframe: "5 days", impact: "See everything, one place" },
        ],
      },
      {
        id: "meeting-preparation-chaos",
        title: "Meeting Preparation Chaos",
        insight:
          "Advisors scramble before client meetings. Print reports. Review scattered notes. Arrive stressed. First 10 minutes wasted orienting.",
        monthlyImpact: 6400,
        psychology:
          "Preparation time compounds. Stress leaks into meetings. Clients sense disorganization. Confidence erodes invisibly.",
        solutions: [
          { title: "Auto-generated meeting briefs", timeframe: "3 days", impact: "All context, one document" },
          { title: "Talking points AI", timeframe: "1 week", impact: "Intelligent agenda suggestions" },
          { title: "One-click report generation", timeframe: "5 days", impact: "Professional materials instantly" },
        ],
      },
    ],
  },
  {
    id: "marketing",
    name: "Marketing",
    icon: "📊",
    tagline: "Problems every business faces",
    problems: [
      {
        id: "invisible-online",
        title: "Invisible Online",
        insight:
          "Your business exists. Google doesn't know. Potential customers search for your services. Competitors appear. You don't.",
        monthlyImpact: 8900,
        psychology:
          "Customers trust Google's first page. Invisibility equals non-existence. Every day invisible is revenue given to competitors.",
        solutions: [
          { title: "Technical SEO foundation", timeframe: "1 week", impact: "Get indexed and ranked" },
          { title: "Local search optimization", timeframe: "5 days", impact: "Dominate your geography" },
          { title: "Content authority building", timeframe: "2 weeks", impact: "Answer what customers ask" },
        ],
      },
      {
        id: "social-media-silence",
        title: "Social Media Silence",
        insight:
          "You post occasionally. Crickets. Competitors have engaged communities. You're shouting into the void. Brand awareness stagnates.",
        monthlyImpact: 6200,
        psychology:
          "Consistency beats quality. Humans follow patterns. Sporadic posting signals unreliability. Algorithms punish inconsistency.",
        solutions: [
          { title: "Content calendar automation", timeframe: "48 hours", impact: "Never miss a post" },
          { title: "Engagement trigger system", timeframe: "3 days", impact: "Turn followers into community" },
          { title: "Performance analytics dashboard", timeframe: "1 week", impact: "Double down on what works" },
        ],
      },
      {
        id: "website-conversion-blackhole",
        title: "Website Conversion Blackhole",
        insight:
          "Traffic comes to your site. They browse. They leave without contacting you. Your website is a brochure, not a sales machine.",
        monthlyImpact: 11400,
        psychology:
          "Visitors need clear next steps. Friction kills conversion. Every extra click loses 20% of prospects. Anxiety prevents action.",
        solutions: [
          { title: "Conversion funnel optimization", timeframe: "1 week", impact: "Guide visitors to action" },
          { title: "Strategic CTA placement", timeframe: "3 days", impact: "Make contact irresistible" },
          { title: "Trust signal engineering", timeframe: "5 days", impact: "Overcome decision paralysis" },
        ],
      },
      {
        id: "ad-budget-bonfire",
        title: "Ad Budget Bonfire",
        insight:
          "You run ads. Clicks come in. Few convert. Budget evaporates. You can't tell what works. Keep spending, hoping for results.",
        monthlyImpact: 14700,
        psychology:
          "Hope is not a strategy. Without attribution, you're gambling. Marketers chase vanity metrics. ROI remains invisible.",
        solutions: [
          { title: "Attribution modeling", timeframe: "1 week", impact: "Know what drives revenue" },
          { title: "Campaign performance automation", timeframe: "5 days", impact: "Kill losers, scale winners" },
          { title: "Landing page optimization", timeframe: "3 days", impact: "Match message to audience" },
        ],
      },
      {
        id: "email-marketing-graveyard",
        title: "Email Marketing Graveyard",
        insight:
          "You collect emails but rarely send. When you do, open rates are dismal. Unsubscribes sting. Your list decays monthly.",
        monthlyImpact: 5600,
        psychology:
          "Infrequent senders are forgotten. Batch-and-blast feels spammy. Without segmentation, relevance dies. Every bad email damages the relationship.",
        solutions: [
          { title: "Behavior-based segmentation", timeframe: "1 week", impact: "Right message, right person" },
          { title: "Automated nurture sequences", timeframe: "5 days", impact: "Stay top of mind effortlessly" },
          { title: "Re-engagement campaigns", timeframe: "3 days", impact: "Revive dormant subscribers" },
        ],
      },
      {
        id: "brand-inconsistency",
        title: "Brand Inconsistency",
        insight:
          "Your website, social media, and materials look like different companies. Customers feel confused. Trust erodes. You seem unprofessional.",
        monthlyImpact: 4300,
        psychology:
          "Consistency signals competence. Visual chaos breeds distrust. Brand recognition requires repetition. Confusion kills conversion.",
        solutions: [
          { title: "Brand guideline creation", timeframe: "1 week", impact: "Define your visual identity" },
          { title: "Template system rollout", timeframe: "5 days", impact: "Consistent materials at scale" },
          { title: "Cross-platform audit", timeframe: "3 days", impact: "Align every touchpoint" },
        ],
      },
      {
        id: "competitor-intelligence-void",
        title: "Competitor Intelligence Void",
        insight:
          "You guess what competitors do. Miss their campaigns. React too late. They out-maneuver you repeatedly. You're always playing catch-up.",
        monthlyImpact: 7100,
        psychology:
          "Markets reward speed. Competitors innovate constantly. Without monitoring, you're blind. Strategic advantages evaporate.",
        solutions: [
          { title: "Competitive monitoring automation", timeframe: "1 week", impact: "Know their every move" },
          { title: "Market positioning analysis", timeframe: "5 days", impact: "Identify white space opportunities" },
          { title: "Campaign response playbooks", timeframe: "3 days", impact: "React faster than they move" },
        ],
      },
    ],
  },
]

// Export the new verticals structure
export function getVertical(id: string): VerticalData | undefined {
  return verticals.find((v) => v.id === id)
}

export function calculateTotalImpact(problems: Problem[]): number {
  return problems.reduce((sum, p) => sum + p.monthlyImpact, 0)
}

export interface QuickWin {
  title: string
  timeToWin: string
  impact: string
  description: string
}

export interface Module {
  id: string
  title: string
  description: string
  icon: string
}

export interface VerticalDataOld {
  name: string
  kpis: KPI[]
  problems: Problem[]
  modules: Module[]
}

export const verticalData: Record<string, VerticalDataOld> = {
  restaurant: {
    name: "Restaurant",
    kpis: [
      {
        label: "Monthly Revenue",
        value: "€45,000",
        delta: -8,
        tooltip: "Based on average ticket size × covers per month",
      },
      { label: "Reservation Rate", value: "68%", delta: -12, tooltip: "Confirmed bookings / total inquiries" },
      { label: "No-show Rate", value: "18%", delta: 15, tooltip: "No-shows / total reservations" },
      { label: "Admin Hours/Week", value: "22h", delta: 25, tooltip: "Time spent on manual booking management" },
    ],
    problems: [
      {
        id: "no-shows",
        title: "No-shows & Cancellations",
        description: "18% no-show rate costing revenue and wasting prep time.",
        monthlyLoss: 3200,
        impact: "high",
        cause: "No automated reminders 24h before reservation. Customers forget.",
        quickWins: [
          {
            title: "Auto SMS reminders",
            timeToWin: "48h",
            impact: "+60% reduction",
            description: "Send automated SMS 24h before booking",
          },
          {
            title: "Confirmation workflow",
            timeToWin: "72h",
            impact: "+40% confirmed",
            description: "Require click-to-confirm 48h prior",
          },
          {
            title: "Waitlist automation",
            timeToWin: "48h",
            impact: "€800/mo recovered",
            description: "Auto-fill from waitlist on cancellation",
          },
        ],
      },
      {
        id: "booking-admin",
        title: "Booking Admin Overload",
        description: "Staff spends 22h/week managing phone/email reservations manually.",
        monthlyLoss: 1800,
        impact: "medium",
        cause: "No unified booking system. Phone, email, Instagram DMs all handled separately.",
        quickWins: [
          {
            title: "BookingBoard widget",
            timeToWin: "72h",
            impact: "-50% admin time",
            description: "Self-serve booking with instant confirmation",
          },
          {
            title: "Channel aggregation",
            timeToWin: "5 days",
            impact: "-30% duplicate entries",
            description: "Single dashboard for all booking sources",
          },
          {
            title: "Voice assistant",
            timeToWin: "7 days",
            impact: "-70% phone time",
            description: "AI handles phone reservations 24/7",
          },
        ],
      },
      {
        id: "inventory-waste",
        title: "Inventory Waste",
        description: "Estimated 12% food waste due to poor demand forecasting.",
        monthlyLoss: 2400,
        impact: "high",
        cause: "Manual stock ordering without predictive data. Over-ordering perishables.",
        quickWins: [
          {
            title: "StockFlow predictions",
            timeToWin: "5 days",
            impact: "-40% waste",
            description: "ML-based demand forecasting from booking data",
          },
          {
            title: "Auto-reorder triggers",
            timeToWin: "48h",
            impact: "-25% stock-outs",
            description: "Automatic supplier orders based on par levels",
          },
          {
            title: "Expiry alerts",
            timeToWin: "24h",
            impact: "€300/mo saved",
            description: "Daily alerts for near-expiry items",
          },
        ],
      },
      {
        id: "marketing-leakage",
        title: "Marketing Budget Leakage",
        description: "Social ads bring inquiries, but 40% never convert to bookings.",
        monthlyLoss: 1600,
        impact: "medium",
        cause: "No automated follow-up. Inquiries go cold within 48 hours.",
        quickWins: [
          {
            title: "Auto follow-up sequence",
            timeToWin: "48h",
            impact: "+25% conversion",
            description: "Instant response + 24h/48h follow-up SMS",
          },
          {
            title: "Lead scoring",
            timeToWin: "5 days",
            impact: "+15% qualified leads",
            description: "Prioritize high-intent inquiries",
          },
          {
            title: "Retargeting sync",
            timeToWin: "3 days",
            impact: "€400/mo ROI",
            description: "Auto-sync unconverted leads to Meta/Google",
          },
        ],
      },
      {
        id: "repeat-customers",
        title: "Low Repeat Rate",
        description: "Only 22% of diners return. Missing retention automation.",
        monthlyLoss: 2800,
        impact: "high",
        cause: "No post-visit engagement. Customers forget about you after one visit.",
        quickWins: [
          {
            title: "Thank-you automation",
            timeToWin: "48h",
            impact: "+18% repeat rate",
            description: "Auto SMS/email 3 days post-visit with incentive",
          },
          {
            title: "Birthday campaigns",
            timeToWin: "72h",
            impact: "€600/mo revenue",
            description: "Auto birthday offers based on booking data",
          },
          {
            title: "Loyalty points",
            timeToWin: "7 days",
            impact: "+12% visit frequency",
            description: "Points per booking, auto-redemption",
          },
        ],
      },
      {
        id: "table-utilization",
        title: "Poor Table Utilization",
        description: "Tables sit empty during off-peak. Dynamic pricing not implemented.",
        monthlyLoss: 1900,
        impact: "medium",
        cause: "Fixed pricing regardless of demand. No incentive to fill off-peak slots.",
        quickWins: [
          {
            title: "Dynamic pricing",
            timeToWin: "5 days",
            impact: "+20% off-peak bookings",
            description: "Auto discounts for low-demand time slots",
          },
          {
            title: "Flash deals",
            timeToWin: "48h",
            impact: "€500/mo incremental",
            description: "SMS/email blast for same-day availability",
          },
          {
            title: "Capacity optimizer",
            timeToWin: "7 days",
            impact: "+8% covers/week",
            description: "AI suggests optimal table assignments",
          },
        ],
      },
    ],
    modules: [
      {
        id: "booking-board",
        title: "BookingBoard",
        description: "Self-serve reservations with instant confirmation",
        icon: "📅",
      },
      { id: "voice-ops", title: "VoiceOps", description: "AI phone assistant handles reservations 24/7", icon: "📞" },
      { id: "stock-flow", title: "StockFlow", description: "Predictive inventory with auto-reorder", icon: "📦" },
      { id: "admin-pulse", title: "AdminPulse", description: "Unified dashboard for all booking channels", icon: "⚡" },
    ],
  },
  clinic: {
    name: "Medical Clinic",
    kpis: [
      { label: "Monthly Patients", value: "420", delta: -15, tooltip: "Unique patients seen per month" },
      { label: "Appointment Fill Rate", value: "72%", delta: -10, tooltip: "Booked slots / available slots" },
      { label: "No-show Rate", value: "22%", delta: 18, tooltip: "No-shows / scheduled appointments" },
      { label: "Admin Hours/Week", value: "28h", delta: 30, tooltip: "Time spent on scheduling & reminders" },
    ],
    problems: [
      {
        id: "no-shows-clinic",
        title: "Patient No-shows",
        description: "22% no-show rate disrupts schedule and loses revenue.",
        monthlyLoss: 4200,
        impact: "high",
        cause: "Manual phone reminders only. Patients forget or don't receive confirmation.",
        quickWins: [
          {
            title: "Auto SMS reminders",
            timeToWin: "48h",
            impact: "-65% no-shows",
            description: "Multi-stage reminders: 48h, 24h, 2h before appointment",
          },
          {
            title: "Confirmation required",
            timeToWin: "72h",
            impact: "+50% confirmed",
            description: "Click-to-confirm 24h prior or slot released",
          },
          {
            title: "Waitlist auto-fill",
            timeToWin: "48h",
            impact: "€1,200/mo recovered",
            description: "Auto-offer cancelled slots to waitlist",
          },
        ],
      },
      {
        id: "scheduling-chaos",
        title: "Scheduling Chaos",
        description: "Staff spends 28h/week on phone scheduling and rescheduling.",
        monthlyLoss: 2400,
        impact: "high",
        cause: "No online booking. Everything by phone or walk-in.",
        quickWins: [
          {
            title: "Online self-booking",
            timeToWin: "72h",
            impact: "-60% phone time",
            description: "Patient portal with real-time availability",
          },
          {
            title: "Voice assistant",
            timeToWin: "5 days",
            impact: "-40% staff interruptions",
            description: "AI handles routine scheduling 24/7",
          },
          {
            title: "Recurring appointments",
            timeToWin: "48h",
            impact: "-20% admin load",
            description: "Auto-schedule follow-ups and check-ups",
          },
        ],
      },
      {
        id: "missed-follow-ups",
        title: "Missed Follow-ups",
        description: "35% of patients miss recommended follow-up appointments.",
        monthlyLoss: 3100,
        impact: "high",
        cause: "No automated follow-up reminders. Patients told verbally but forget.",
        quickWins: [
          {
            title: "Auto follow-up sequence",
            timeToWin: "48h",
            impact: "+45% follow-up rate",
            description: "Automatic reminders at prescribed intervals",
          },
          {
            title: "Smart scheduling",
            timeToWin: "5 days",
            impact: "+30% compliance",
            description: "Suggest optimal follow-up times based on patient history",
          },
          {
            title: "Prescription reminders",
            timeToWin: "72h",
            impact: "€800/mo retained",
            description: "Auto refill reminders with online booking",
          },
        ],
      },
      {
        id: "insurance-delays",
        title: "Insurance Processing Delays",
        description: "Insurance claims delayed due to manual data entry and errors.",
        monthlyLoss: 1800,
        impact: "medium",
        cause: "Staff manually enter patient data into insurance portals. Frequent errors.",
        quickWins: [
          {
            title: "LedgerLink automation",
            timeToWin: "7 days",
            impact: "-50% processing time",
            description: "Auto-populate insurance forms from patient records",
          },
          {
            title: "Error detection",
            timeToWin: "5 days",
            impact: "-70% rejected claims",
            description: "Real-time validation before submission",
          },
          {
            title: "Status tracking",
            timeToWin: "48h",
            impact: "€600/mo cash flow",
            description: "Auto-chase pending claims with alerts",
          },
        ],
      },
      {
        id: "referral-leakage",
        title: "Referral Leakage",
        description: "Doctor referrals given verbally; 40% never schedule.",
        monthlyLoss: 2200,
        impact: "medium",
        cause: "Paper referral slips. No follow-up to ensure patient books specialist.",
        quickWins: [
          {
            title: "Digital referral workflow",
            timeToWin: "5 days",
            impact: "+35% conversion",
            description: "SMS with direct booking link sent to patient & specialist",
          },
          {
            title: "Referral tracking",
            timeToWin: "72h",
            impact: "+25% completed",
            description: "Auto-chase patients who don't book within 7 days",
          },
          {
            title: "Specialist network",
            timeToWin: "7 days",
            impact: "€700/mo network effect",
            description: "Integrated calendar with partner specialists",
          },
        ],
      },
      {
        id: "patient-comms",
        title: "Inefficient Patient Communications",
        description: "Test results, updates, and admin messages via phone tag.",
        monthlyLoss: 1400,
        impact: "low",
        cause: "No secure messaging system. Staff play phone tag for non-urgent updates.",
        quickWins: [
          {
            title: "Patient portal messaging",
            timeToWin: "5 days",
            impact: "-40% phone calls",
            description: "Secure async messaging for test results & queries",
          },
          {
            title: "Auto test notifications",
            timeToWin: "48h",
            impact: "-60% outbound calls",
            description: "SMS/email when results ready with portal link",
          },
          {
            title: "Bulk announcements",
            timeToWin: "24h",
            impact: "€300/mo saved",
            description: "One-click SMS/email to all patients (flu shots, closures)",
          },
        ],
      },
    ],
    modules: [
      {
        id: "booking-board",
        title: "BookingBoard",
        description: "Online appointment scheduling for patients",
        icon: "📅",
      },
      { id: "voice-ops", title: "VoiceOps", description: "AI assistant handles routine scheduling calls", icon: "📞" },
      { id: "admin-pulse", title: "AdminPulse", description: "Unified patient communications dashboard", icon: "⚡" },
      { id: "ledger-link", title: "LedgerLink", description: "Automated insurance claim processing", icon: "💰" },
    ],
  },
  retail: {
    name: "Retail",
    kpis: [
      { label: "Monthly Revenue", value: "€68,000", delta: -5, tooltip: "Total sales across all channels" },
      { label: "Conversion Rate", value: "2.8%", delta: -18, tooltip: "Purchases / website visitors" },
      { label: "Cart Abandonment", value: "74%", delta: 12, tooltip: "Carts not completed / total carts" },
      { label: "Inventory Accuracy", value: "81%", delta: -15, tooltip: "Physical count vs system count" },
    ],
    problems: [
      {
        id: "cart-abandonment",
        title: "Cart Abandonment",
        description: "74% of carts abandoned. No automated recovery.",
        monthlyLoss: 5200,
        impact: "high",
        cause: "No abandoned cart emails or SMS. Customers leave and forget.",
        quickWins: [
          {
            title: "Auto cart recovery",
            timeToWin: "48h",
            impact: "+12% recovered sales",
            description: "Email + SMS sequence at 1h, 24h, 72h",
          },
          {
            title: "Exit intent offers",
            timeToWin: "72h",
            impact: "+8% immediate conversion",
            description: "Popup discount when user attempts to leave",
          },
          {
            title: "Personalized reminders",
            timeToWin: "5 days",
            impact: "+15% recovery rate",
            description: "Product-specific messaging based on cart contents",
          },
        ],
      },
      {
        id: "inventory-stock-outs",
        title: "Inventory Stock-outs",
        description: "Frequent out-of-stock on best-sellers. Manual reordering.",
        monthlyLoss: 3800,
        impact: "high",
        cause: "Reactive ordering. No predictive restock based on sales velocity.",
        quickWins: [
          {
            title: "StockFlow predictions",
            timeToWin: "5 days",
            impact: "-60% stock-outs",
            description: "ML forecasting triggers reorders before depletion",
          },
          {
            title: "Auto-reorder rules",
            timeToWin: "48h",
            impact: "-40% manual work",
            description: "Set par levels; system orders automatically",
          },
          {
            title: "Back-in-stock alerts",
            timeToWin: "72h",
            impact: "€900/mo recovered",
            description: "Auto-notify waitlist when items restock",
          },
        ],
      },
      {
        id: "missed-leads-retail",
        title: "Missed Online Inquiries",
        description: "Product questions via contact form; 50% never get response.",
        monthlyLoss: 2100,
        impact: "medium",
        cause: "Contact forms checked sporadically. No SLA for inquiry response.",
        quickWins: [
          {
            title: "Auto-response system",
            timeToWin: "48h",
            impact: "+35% conversion",
            description: "Instant acknowledgment + AI-powered answers to common questions",
          },
          {
            title: "TicketTom routing",
            timeToWin: "72h",
            impact: "-70% response time",
            description: "Auto-assign inquiries to right team member",
          },
          {
            title: "Live chat bot",
            timeToWin: "5 days",
            impact: "+20% immediate sales",
            description: "24/7 AI chat for product questions & upsells",
          },
        ],
      },
      {
        id: "loyalty-gaps",
        title: "No Retention Strategy",
        description: "One-time buyers. No repeat purchase automation.",
        monthlyLoss: 2900,
        impact: "high",
        cause: "No post-purchase email sequence or loyalty program.",
        quickWins: [
          {
            title: "Post-purchase flow",
            timeToWin: "48h",
            impact: "+22% repeat rate",
            description: "Thank you email + 30-day replenishment reminder",
          },
          {
            title: "Loyalty points",
            timeToWin: "7 days",
            impact: "+18% LTV",
            description: "Auto points per purchase, redemption reminders",
          },
          {
            title: "Win-back campaigns",
            timeToWin: "72h",
            impact: "€1,100/mo recovered",
            description: "Auto re-engage customers 60/90 days after last order",
          },
        ],
      },
      {
        id: "pricing-errors",
        title: "Pricing & Promo Errors",
        description: "Manual promo code application leads to errors and lost margin.",
        monthlyLoss: 1600,
        impact: "medium",
        cause: "Promo codes managed in spreadsheet. Codes stack incorrectly or expire unannounced.",
        quickWins: [
          {
            title: "Promo automation",
            timeToWin: "5 days",
            impact: "-80% errors",
            description: "Centralized promo logic with auto expiry & rules",
          },
          {
            title: "Dynamic pricing",
            timeToWin: "7 days",
            impact: "+5% margin",
            description: "Auto-adjust prices by inventory age, demand",
          },
          {
            title: "Margin alerts",
            timeToWin: "48h",
            impact: "€400/mo saved",
            description: "Real-time alert when discount exceeds threshold",
          },
        ],
      },
      {
        id: "returns-admin",
        title: "Returns Processing Overhead",
        description: "Manual returns handling creates backlog and customer frustration.",
        monthlyLoss: 1200,
        impact: "low",
        cause: "No self-serve return portal. All returns require staff emails.",
        quickWins: [
          {
            title: "Self-serve returns",
            timeToWin: "5 days",
            impact: "-50% admin time",
            description: "Customer portal for return requests & label generation",
          },
          {
            title: "Auto-refund workflow",
            timeToWin: "7 days",
            impact: "-30% processing time",
            description: "Trigger refund on receipt scan; no manual review",
          },
          {
            title: "Return analytics",
            timeToWin: "72h",
            impact: "€300/mo saved",
            description: "Identify high-return SKUs for quality review",
          },
        ],
      },
    ],
    modules: [
      { id: "stock-flow", title: "StockFlow", description: "Predictive inventory & auto-reorder", icon: "📦" },
      { id: "sales-pipeline", title: "SalesPipeline", description: "Lead routing & conversion tracking", icon: "📈" },
      { id: "ticket-tom", title: "TicketTom", description: "Customer inquiry auto-routing & AI answers", icon: "🎫" },
      { id: "admin-pulse", title: "AdminPulse", description: "Centralized promo & returns dashboard", icon: "⚡" },
    ],
  },
  "real-estate": {
    name: "Real Estate",
    kpis: [
      { label: "Active Listings", value: "28", delta: -10, tooltip: "Properties currently marketed" },
      { label: "Viewing Conversion", value: "18%", delta: -22, tooltip: "Viewings that lead to offers" },
      { label: "Lead Response Time", value: "4.2h", delta: 35, tooltip: "Average time to respond to inquiries" },
      { label: "Admin Hours/Week", value: "32h", delta: 40, tooltip: "Time on scheduling, follow-ups, paperwork" },
    ],
    problems: [
      {
        id: "slow-lead-response",
        title: "Slow Lead Response",
        description: "Average 4.2h response time. Leads go cold or contact competitors.",
        monthlyLoss: 4800,
        impact: "high",
        cause: "Leads arrive via web, email, phone, WhatsApp. No unified inbox or auto-response.",
        quickWins: [
          {
            title: "Instant auto-response",
            timeToWin: "48h",
            impact: "+40% engagement",
            description: "Immediate SMS/email with property details & booking link",
          },
          {
            title: "Lead routing",
            timeToWin: "72h",
            impact: "-70% response time",
            description: "Auto-assign to agent by location & availability",
          },
          {
            title: "VoiceOps answering",
            timeToWin: "5 days",
            impact: "24/7 coverage",
            description: "AI handles after-hours inquiries & books viewings",
          },
        ],
      },
      {
        id: "viewing-scheduling",
        title: "Viewing Scheduling Chaos",
        description: "32h/week spent coordinating viewings via phone tag.",
        monthlyLoss: 2800,
        impact: "high",
        cause: "No self-serve viewing scheduler. Everything via back-and-forth calls.",
        quickWins: [
          {
            title: "Self-serve booking",
            timeToWin: "72h",
            impact: "-60% admin time",
            description: "Prospects book viewings online with real-time availability",
          },
          {
            title: "Auto confirmations",
            timeToWin: "48h",
            impact: "-50% no-shows",
            description: "SMS confirmations 24h prior with calendar invite",
          },
          {
            title: "Route optimization",
            timeToWin: "5 days",
            impact: "+5 viewings/day",
            description: "AI suggests optimal viewing routes for agents",
          },
        ],
      },
      {
        id: "pipeline-leakage",
        title: "Pipeline Leakage",
        description: "45% of qualified leads drop off due to no systematic follow-up.",
        monthlyLoss: 5200,
        impact: "high",
        cause: "Manual CRM updates. Leads fall through cracks without automated nurture.",
        quickWins: [
          {
            title: "SalesPipeline automation",
            timeToWin: "5 days",
            impact: "+30% conversion",
            description: "Auto-nurture sequences based on lead stage",
          },
          {
            title: "Follow-up reminders",
            timeToWin: "48h",
            impact: "-40% drop-off",
            description: "Daily digest of overdue follow-ups for agents",
          },
          {
            title: "Engagement scoring",
            timeToWin: "7 days",
            impact: "+25% qualified deals",
            description: "Prioritize hot leads by email/web activity",
          },
        ],
      },
      {
        id: "listing-admin",
        title: "Listing Admin Overload",
        description: "Manual listing uploads to multiple portals. Frequent errors.",
        monthlyLoss: 1600,
        impact: "medium",
        cause: "Copy-paste listings to 5+ platforms. Photos and descriptions get out of sync.",
        quickWins: [
          {
            title: "Multi-portal sync",
            timeToWin: "7 days",
            impact: "-70% upload time",
            description: "Single input → auto-publish to all portals",
          },
          {
            title: "Photo optimizer",
            timeToWin: "48h",
            impact: "+15% viewing requests",
            description: "Auto-enhance & resize images for each platform",
          },
          {
            title: "Status tracking",
            timeToWin: "72h",
            impact: "€500/mo saved",
            description: "Real-time dashboard of listing status across portals",
          },
        ],
      },
      {
        id: "document-bottleneck",
        title: "Document Bottleneck",
        description: "Offer letters, contracts, disclosures all manual. Slow closing.",
        monthlyLoss: 2100,
        impact: "medium",
        cause: "Word templates filled manually. Frequent errors delay closings.",
        quickWins: [
          {
            title: "Document automation",
            timeToWin: "5 days",
            impact: "-60% prep time",
            description: "Auto-generate contracts from CRM data",
          },
          {
            title: "E-signature workflow",
            timeToWin: "72h",
            impact: "-50% closing time",
            description: "Integrated DocuSign with auto-reminders",
          },
          {
            title: "Compliance checklist",
            timeToWin: "48h",
            impact: "€400/mo risk reduction",
            description: "Auto-verify all required disclosures present",
          },
        ],
      },
      {
        id: "open-house-waste",
        title: "Open House Waste",
        description: "Poor open house attendance. No pre-qualification or follow-up.",
        monthlyLoss: 1900,
        impact: "medium",
        cause: "Open houses promoted via social posts. No RSVP system or lead capture.",
        quickWins: [
          {
            title: "RSVP & reminders",
            timeToWin: "48h",
            impact: "+45% attendance",
            description: "Online RSVP with auto SMS reminders day-of",
          },
          {
            title: "Lead capture app",
            timeToWin: "72h",
            impact: "+60% follow-up rate",
            description: "Tablet at door captures contact info & preferences",
          },
          {
            title: "Auto follow-up",
            timeToWin: "48h",
            impact: "+20% conversion",
            description: "Thank you email + property brochure sent within 1h",
          },
        ],
      },
    ],
    modules: [
      {
        id: "sales-pipeline",
        title: "SalesPipeline",
        description: "Automated lead nurture & deal tracking",
        icon: "📈",
      },
      { id: "booking-board", title: "BookingBoard", description: "Self-serve viewing scheduler", icon: "📅" },
      { id: "voice-ops", title: "VoiceOps", description: "AI handles property inquiries 24/7", icon: "📞" },
      { id: "admin-pulse", title: "AdminPulse", description: "Unified listing & document management", icon: "⚡" },
    ],
  },
  agency: {
    name: "Agency",
    kpis: [
      { label: "Active Clients", value: "12", delta: -8, tooltip: "Clients with ongoing retainers or projects" },
      { label: "Proposal Win Rate", value: "28%", delta: -15, tooltip: "Proposals accepted / total proposals sent" },
      { label: "Project Margin", value: "34%", delta: -12, tooltip: "Net profit / project revenue" },
      { label: "Admin Hours/Week", value: "26h", delta: 45, tooltip: "Time on status reports, invoicing, scope docs" },
    ],
    problems: [
      {
        id: "slow-proposals",
        title: "Slow Proposal Generation",
        description: "Each proposal takes 6-8 hours. Many never get sent.",
        monthlyLoss: 3400,
        impact: "high",
        cause: "Proposals built from scratch in Word. Heavy copy-paste and formatting.",
        quickWins: [
          {
            title: "Proposal templates",
            timeToWin: "48h",
            impact: "-70% creation time",
            description: "Library of scope/pricing templates with auto-fill",
          },
          {
            title: "Dynamic pricing",
            timeToWin: "5 days",
            impact: "+15% margin",
            description: "Smart pricing calculator based on scope complexity",
          },
          {
            title: "One-click export",
            timeToWin: "72h",
            impact: "+40% proposals sent",
            description: "Instant PDF generation with e-signature integration",
          },
        ],
      },
      {
        id: "scope-creep",
        title: "Scope Creep & Margin Erosion",
        description: "Projects consistently over-budget due to undefined scope.",
        monthlyLoss: 4200,
        impact: "high",
        cause: 'Vague SOWs. No change request workflow. Team says yes to "small asks".',
        quickWins: [
          {
            title: "Scope tracking",
            timeToWin: "5 days",
            impact: "+20% margin",
            description: "Real-time dashboard of hours vs scope; alerts on overrun",
          },
          {
            title: "Change request workflow",
            timeToWin: "72h",
            impact: "-50% unbilled work",
            description: "Client-facing form auto-generates pricing for add-ons",
          },
          {
            title: "Auto invoicing",
            timeToWin: "48h",
            impact: "€800/mo recovered",
            description: "Trigger invoice when out-of-scope work approved",
          },
        ],
      },
      {
        id: "client-reporting",
        title: "Manual Client Reporting",
        description: "26h/week spent creating status reports and performance decks.",
        monthlyLoss: 2200,
        impact: "high",
        cause: "Custom slides for each client. Data pulled manually from multiple tools.",
        quickWins: [
          {
            title: "Auto-generated reports",
            timeToWin: "7 days",
            impact: "-60% reporting time",
            description: "Connect tools; generate branded reports on schedule",
          },
          {
            title: "Client portal",
            timeToWin: "5 days",
            impact: "-40% status emails",
            description: "Self-serve dashboard for clients to check progress",
          },
          {
            title: "Metric aggregation",
            timeToWin: "72h",
            impact: "€600/mo saved",
            description: "Single dashboard pulling GA, Meta Ads, CRM, etc.",
          },
        ],
      },
      {
        id: "lead-qualification",
        title: "Poor Lead Qualification",
        description: "Too many discovery calls with tire-kickers. Low proposal win rate.",
        monthlyLoss: 2800,
        impact: "medium",
        cause: "No pre-qualification form. Anyone can book a call.",
        quickWins: [
          {
            title: "Pre-call questionnaire",
            timeToWin: "48h",
            impact: "+35% qualified calls",
            description: "Require budget/timeline before booking",
          },
          {
            title: "Auto-disqualify rules",
            timeToWin: "72h",
            impact: "-50% wasted calls",
            description: "AI scores leads; only book if threshold met",
          },
          {
            title: "Case study matcher",
            timeToWin: "5 days",
            impact: "+20% win rate",
            description: "Auto-send relevant case studies based on prospect industry",
          },
        ],
      },
      {
        id: "invoice-delays",
        title: "Invoice Payment Delays",
        description: "Average 45 days to payment. No automated chasing.",
        monthlyLoss: 1800,
        impact: "medium",
        cause: "Invoices sent manually via email. No follow-up system for overdue.",
        quickWins: [
          {
            title: "Auto invoice reminders",
            timeToWin: "48h",
            impact: "-30% payment time",
            description: "Reminders at 7, 14, 21 days; escalating tone",
          },
          {
            title: "Payment portal",
            timeToWin: "72h",
            impact: "+25% on-time payment",
            description: "One-click payment link in invoice email",
          },
          {
            title: "Late fee automation",
            timeToWin: "48h",
            impact: "€500/mo recovered",
            description: "Auto-calculate & add late fees per contract terms",
          },
        ],
      },
      {
        id: "resource-allocation",
        title: "Resource Allocation Chaos",
        description: "No visibility into team capacity. Over-commit or under-utilize.",
        monthlyLoss: 2600,
        impact: "medium",
        cause: "Projects tracked in spreadsheets. No real-time capacity view.",
        quickWins: [
          {
            title: "Capacity dashboard",
            timeToWin: "5 days",
            impact: "+18% utilization",
            description: "Real-time view of team availability & project load",
          },
          {
            title: "Smart assignment",
            timeToWin: "7 days",
            impact: "-30% bottlenecks",
            description: "AI suggests optimal resource allocation",
          },
          {
            title: "Overload alerts",
            timeToWin: "48h",
            impact: "€700/mo saved",
            description: "Alert manager when team member >100% allocated",
          },
        ],
      },
    ],
    modules: [
      { id: "sales-pipeline", title: "SalesPipeline", description: "Lead scoring & proposal tracking", icon: "📈" },
      { id: "admin-pulse", title: "AdminPulse", description: "Centralized reporting & invoicing", icon: "⚡" },
      { id: "ticket-tom", title: "TicketTom", description: "Client request tracking & prioritization", icon: "🎫" },
      { id: "ledger-link", title: "LedgerLink", description: "Automated invoicing & payment reminders", icon: "💰" },
    ],
  },
}

export function calculateTotalLoss(problems: Problem[], appliedFixes: Set<string>): number {
  return problems.reduce((total, problem) => {
    if (appliedFixes.has(problem.id)) {
      return total + problem.monthlyLoss * 0.4 // 60% reduction when fix applied
    }
    return total + problem.monthlyLoss
  }, 0)
}

export function getBusinessSize(size: string) {
  const sizes = {
    solo: { multiplier: 0.5, label: "Solo / Micro" },
    sme: { multiplier: 1.0, label: "Small / Medium" },
    enterprise: { multiplier: 2.5, label: "Enterprise" },
  }
  return sizes[size as keyof typeof sizes] || sizes.sme
}
