"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Play, Shield, Zap, BarChart3, TrendingDown, TrendingUp } from "lucide-react"
import { verticals } from "@/lib/demo-data"
import { Typewriter } from "@/components/typewriter"
import { ParticleBackground } from "@/components/particles"
import { useState } from "react"

export default function LandingPage() {
  const [typewriterComplete, setTypewriterComplete] = useState(false)

  return (
    <div className="min-h-screen bg-background overflow-hidden relative">
      <ParticleBackground />

      {/* Ambient background glow */}
      <div className="fixed inset-0 bg-gradient-radial pointer-events-none" />

      {/* Animated background grid */}
      <div className="fixed inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

      {/* Header */}
      <header className="relative z-10 border-b border-border/50 backdrop-blur-xl bg-background/80">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between fade-in">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-transparent" />
              <div className="w-4 h-4 rounded-sm bg-primary relative z-10" />
            </div>
            <span className="text-lg font-semibold tracking-tight">OARC</span>
          </div>
          <Button asChild variant="ghost" className="text-muted-foreground hover:text-foreground">
            <Link href="/dashboard-demo">
              <Play className="mr-2 h-4 w-4" />
              Experience Demo
            </Link>
          </Button>
        </div>
      </header>

      {/* Hero */}
      <section className="relative z-10 container mx-auto px-6 pt-20 pb-16 md:pt-32 md:pb-24">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass text-sm text-muted-foreground fade-in-up">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            AI-Powered Business Intelligence Platform
          </div>

          <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-[1.1] fade-in-up delay-200">
            <Typewriter
              text="Discover what's costing you"
              delay={60}
              className="block"
              onComplete={() => setTypewriterComplete(true)}
            />
            {typewriterComplete && (
              <span className="text-gradient block mt-2 fade-in-up">before your competitors do</span>
            )}
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty leading-relaxed fade-in-up delay-400">
            Enterprise-grade diagnostics that identify revenue leakage, operational inefficiencies, and hidden cost
            centers across 8 industries. Backed by behavioral economics and real-time data analysis.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4 fade-in-up delay-600">
            <Button asChild size="lg" className="text-base px-8 h-14 rounded-xl shadow-lg shadow-primary/25">
              <Link href="/dashboard-demo">
                See Your Solutions Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-base px-8 h-14 rounded-xl bg-transparent">
              <Link href="/offer">
                <Shield className="mr-2 h-5 w-5" />
                14-Day Pilot Program
              </Link>
            </Button>
          </div>

          <div className="pt-8 flex items-center justify-center gap-8 text-sm text-muted-foreground fade-in-up delay-800">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              <span>48-hour implementation</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" />
              <span>Results guaranteed</span>
            </div>
          </div>
        </div>
      </section>

      {/* Live Demo Preview */}
      <section className="relative z-10 container mx-auto px-6 pb-24">
        <div className="max-w-5xl mx-auto">
          <div className="glass-strong rounded-3xl p-8 md:p-12 scale-in delay-400 relative overflow-hidden">
            {/* Glow effect */}
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/20 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-accent/20 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl md:text-3xl font-bold mb-2">Live Business Diagnostics</h2>
                  <p className="text-muted-foreground">Real-time analysis from {verticals[0].name} operations</p>
                </div>
                <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-full bg-destructive/10 border border-destructive/20">
                  <TrendingDown className="h-4 w-4 text-destructive" />
                  <span className="text-sm font-semibold text-destructive">
                    {new Intl.NumberFormat("en-EU", {
                      style: "currency",
                      currency: "EUR",
                      maximumFractionDigits: 0,
                    }).format(verticals[0].problems.slice(0, 3).reduce((sum, p) => sum + p.monthlyImpact, 0))}
                    /mo
                  </span>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                {verticals[0].problems.slice(0, 3).map((problem, i) => (
                  <div
                    key={problem.id}
                    className={`p-6 rounded-2xl bg-background/50 border border-border/50 backdrop-blur-sm space-y-4 hover:bg-background/70 transition-all hover:scale-105 hover:shadow-xl fade-in-up`}
                    style={{ animationDelay: `${600 + i * 100}ms` }}
                  >
                    <div className="flex items-start justify-between">
                      <span className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">
                        Critical Issue #{i + 1}
                      </span>
                      <span className="text-sm text-destructive/90 font-bold">
                        -€{(problem.monthlyImpact / 1000).toFixed(1)}K
                      </span>
                    </div>
                    <h3 className="font-bold text-lg">{problem.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3">{problem.insight}</p>
                    <div className="pt-2 flex items-center gap-2 text-xs text-primary font-medium">
                      <Zap className="h-3.5 w-3.5" />
                      <span>{problem.solutions.length} solutions available</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 pt-8 border-t border-border/50 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="text-center md:text-left">
                  <p className="text-sm text-muted-foreground mb-1">Projected annual recovery</p>
                  <p className="text-3xl font-bold text-gradient">
                    {new Intl.NumberFormat("en-EU", {
                      style: "currency",
                      currency: "EUR",
                      maximumFractionDigits: 0,
                    }).format(verticals[0].problems.slice(0, 3).reduce((sum, p) => sum + p.monthlyImpact * 12, 0))}
                  </p>
                </div>
                <Button asChild size="lg" className="rounded-xl">
                  <Link href="/dashboard-demo">
                    Analyze Your Industry
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Platform Capabilities */}
      <section className="relative z-10 border-y border-border/50 bg-muted/30 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-24">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16 fade-in-up">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Built for decision-makers who need answers, not dashboards
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                OARC transforms complex operational data into actionable intelligence. Every insight is backed by
                behavioral economics and validated with real numbers.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center space-y-4 slide-in-left delay-200">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <BarChart3 className="h-8 w-8 text-primary relative z-10" />
                </div>
                <h3 className="font-bold text-xl">Real-Time Diagnostics</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Continuous monitoring of 50+ operational metrics across your business. Instant alerts when
                  inefficiencies emerge.
                </p>
              </div>

              <div className="text-center space-y-4 slide-in-left delay-400">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <Zap className="h-8 w-8 text-primary relative z-10" />
                </div>
                <h3 className="font-bold text-xl">Psychology-Backed Solutions</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Not just what's broken, but why. Every problem includes behavioral analysis and proven intervention
                  strategies.
                </p>
              </div>

              <div className="text-center space-y-4 slide-in-left delay-600">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <Shield className="h-8 w-8 text-primary relative z-10" />
                </div>
                <h3 className="font-bold text-xl">Guaranteed Results</h3>
                <p className="text-muted-foreground leading-relaxed">
                  14-day pilot with measurable KPIs. If we don't deliver documented improvements, the pilot is
                  completely free.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Industries Served */}
      <section className="relative z-10 container mx-auto px-6 py-24">
        <div className="max-w-4xl mx-auto text-center space-y-12 fade-in-up">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Trusted across <span className="text-gradient">8 industries</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              Industry-specific diagnostics built on years of operational research and data analysis
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {verticals.map((vertical, i) => (
              <div
                key={vertical.id}
                className={`p-6 rounded-2xl glass hover:glass-strong transition-all hover:scale-105 cursor-pointer group fade-in-up`}
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <div className="text-4xl mb-3 group-hover:scale-110 transition-transform">{vertical.icon}</div>
                <h3 className="font-semibold">{vertical.name}</h3>
                <p className="text-xs text-muted-foreground mt-1">{vertical.problems.length} diagnostics</p>
              </div>
            ))}
          </div>

          <Button asChild size="lg" className="text-base px-8 h-14 rounded-xl shadow-lg shadow-primary/25">
            <Link href="/dashboard-demo">
              Explore Your Industry
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative z-10 container mx-auto px-6 pb-24">
        <div className="max-w-3xl mx-auto text-center glass-strong rounded-3xl p-12 md:p-16 relative overflow-hidden scale-in delay-200">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 pointer-events-none" />

          <div className="relative z-10 space-y-8">
            <div className="inline-flex items-center gap-3 px-5 py-3 rounded-2xl bg-background/50 backdrop-blur-sm">
              <Shield className="h-5 w-5 text-primary" />
              <span className="text-sm font-semibold">Risk-Free 14-Day Pilot</span>
            </div>

            <h2 className="text-3xl md:text-4xl font-bold text-balance">
              See measurable improvements in two weeks, or don't pay a cent
            </h2>

            <p className="text-lg text-muted-foreground leading-relaxed max-w-xl mx-auto">
              Join decision-makers at leading restaurants, clinics, retailers, and agencies who trust OARC to protect
              their bottom line.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button asChild size="lg" className="text-base px-8 h-14 rounded-xl shadow-lg shadow-primary/25">
                <Link href="/offer">
                  Start Your Pilot
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="text-base px-8 h-14 rounded-xl bg-background/50 backdrop-blur-sm"
              >
                <Link href="/dashboard-demo">
                  <Play className="mr-2 h-5 w-5" />
                  Try Demo First
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border/50 py-12 backdrop-blur-xl bg-background/80">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                <div className="w-4 h-4 rounded-sm bg-primary" />
              </div>
              <span className="font-semibold">OARC</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Enterprise Business Intelligence · Trusted by industry leaders worldwide
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
