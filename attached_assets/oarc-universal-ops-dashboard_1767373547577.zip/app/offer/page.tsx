"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Check, Shield, Zap, Clock, ArrowRight, ArrowLeft, Calendar, Users, LineChart } from "lucide-react"
import { ParticleBackground } from "@/components/particles"

export default function OfferPage() {
  return (
    <div className="min-h-screen bg-background relative">
      <ParticleBackground />

      {/* Ambient background */}
      <div className="fixed inset-0 bg-gradient-radial pointer-events-none" />

      {/* Header */}
      <header className="relative z-10 border-b border-border/50 sticky top-0 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between fade-in">
          <div className="flex items-center gap-4">
            <Link
              href="/dashboard-demo"
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span className="text-sm hidden sm:inline">Back to Dashboard</span>
            </Link>
            <div className="h-6 w-px bg-border" />
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-primary/20 flex items-center justify-center">
                <div className="w-3 h-3 rounded-sm bg-primary" />
              </div>
              <span className="font-semibold">OARC</span>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-6 py-12 md:py-20">
        {/* Hero */}
        <div className="max-w-3xl mx-auto text-center mb-16 fade-in-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass text-sm text-muted-foreground mb-6">
            <Shield className="h-4 w-4 text-primary" />
            14-Day Pilot Program
          </div>

          <h1 className="text-3xl md:text-5xl font-bold mb-6 text-balance leading-tight">
            Fix your operations in 14 days
            <br />
            <span className="text-gradient">or it{"'"}s free</span>
          </h1>

          <p className="text-lg text-muted-foreground max-w-xl mx-auto text-pretty leading-relaxed">
            No contracts. No delays. First improvements in 48 hours. We prove value before you commit.
          </p>
        </div>

        {/* Main Offer */}
        <div className="max-w-2xl mx-auto mb-16 scale-in delay-200">
          <div className="glass-strong rounded-3xl p-8 md:p-10 relative overflow-hidden">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/10 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10">
              {/* Price */}
              <div className="text-center mb-10">
                <p className="text-sm text-muted-foreground mb-3">Pilot Investment</p>
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-5xl md:text-6xl font-bold text-gradient">€997</span>
                </div>
                <p className="text-sm text-muted-foreground mt-3">One-time. Results guaranteed.</p>
              </div>

              {/* Timeline */}
              <div className="space-y-6 mb-10">
                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
                      1-2
                    </div>
                    <div className="w-px h-full bg-border/50 my-2" />
                  </div>
                  <div className="pb-6">
                    <p className="font-semibold mb-1">Quick Wins Deployed</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      First automation live within 48 hours. Immediate, visible improvements.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
                      3-7
                    </div>
                    <div className="w-px h-full bg-border/50 my-2" />
                  </div>
                  <div className="pb-6">
                    <p className="font-semibold mb-1">Core Systems Configured</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Your top problems get custom solutions, tailored to how you actually work.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
                      8-14
                    </div>
                    <div className="w-px h-full bg-border/50 my-2" />
                  </div>
                  <div className="pb-6">
                    <p className="font-semibold mb-1">Measure & Validate</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Live dashboard showing recovered revenue and operational improvements.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm">
                      15
                    </div>
                  </div>
                  <div>
                    <p className="font-semibold mb-1">Your Decision</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Results proven? Continue at €297/mo. Not satisfied? Full refund. No questions.
                    </p>
                  </div>
                </div>
              </div>

              {/* CTA */}
              <Button size="lg" className="w-full h-14 rounded-xl text-base shadow-lg shadow-primary/25">
                Start Your Pilot
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Guarantees */}
        <div className="max-w-4xl mx-auto mb-16">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="glass rounded-2xl p-6 text-center fade-in-up delay-300 hover:scale-105 transition-transform">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Results Guarantee</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Measurable improvements in 14 days or full refund. We take the risk.
              </p>
            </div>

            <div className="glass rounded-2xl p-6 text-center fade-in-up delay-400 hover:scale-105 transition-transform">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">48-Hour First Wins</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                See value before the week ends. No waiting months for results.
              </p>
            </div>

            <div className="glass rounded-2xl p-6 text-center fade-in-up delay-500 hover:scale-105 transition-transform">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">No Lock-In</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                After pilot, stay or go. Monthly billing. Cancel anytime.
              </p>
            </div>
          </div>
        </div>

        {/* Post-Pilot Pricing */}
        <div className="max-w-xl mx-auto mb-16 fade-in-up delay-600">
          <div className="glass-strong rounded-2xl p-8">
            <h2 className="text-xl font-bold mb-6 text-center">After Your Pilot</h2>

            <div className="space-y-4 mb-6">
              <div className="flex items-center justify-between py-3 border-b border-border/50">
                <span className="text-muted-foreground">Platform Access</span>
                <span className="font-medium">€197/mo</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-border/50">
                <span className="text-muted-foreground">Active Modules</span>
                <span className="font-medium">€100/mo</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-border/50">
                <span className="text-muted-foreground">Support & Updates</span>
                <span className="font-medium text-primary">Included</span>
              </div>
              <div className="flex items-center justify-between pt-2">
                <span className="font-bold">Monthly Total</span>
                <span className="text-2xl font-bold text-gradient">€297</span>
              </div>
            </div>

            <p className="text-xs text-muted-foreground text-center">
              Most clients see 5-10x ROI within the first month
            </p>
          </div>
        </div>

        {/* What's Included */}
        <div className="max-w-3xl mx-auto mb-16 fade-in-up delay-700">
          <h2 className="text-xl font-bold mb-8 text-center">What{"'"}s Included</h2>

          <div className="grid md:grid-cols-2 gap-4">
            {[
              { icon: LineChart, text: "Custom operations diagnostic" },
              { icon: Zap, text: "Quick-win automations (48h)" },
              { icon: Users, text: "Dedicated implementation specialist" },
              { icon: Calendar, text: "30-minute team training" },
              { icon: Shield, text: "14-day results tracking" },
              { icon: Check, text: "Full refund if no results" },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 p-4 rounded-xl glass hover:glass-strong transition-all">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <item.icon className="h-4 w-4 text-primary" />
                </div>
                <span className="text-sm">{item.text}</span>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ */}
        <div className="max-w-2xl mx-auto mb-16 fade-in-up delay-800">
          <h2 className="text-xl font-bold mb-8 text-center">Questions</h2>

          <div className="space-y-4">
            {[
              {
                q: "What if I'm not technical?",
                a: "We handle everything. You get a simple dashboard and 30-minute training. That's it.",
              },
              {
                q: "What if my business is different?",
                a: "Our modules are configurable. We customize workflows to match how you actually operate.",
              },
              {
                q: "Do I need to change my existing tools?",
                a: "No. OARC integrates with most CRMs, booking systems, and software you already use.",
              },
              {
                q: "What happens after 14 days?",
                a: "You decide. Continue at €297/month if you're seeing results, or cancel with full refund.",
              },
            ].map((faq, i) => (
              <div key={i} className="glass rounded-xl p-5 hover:glass-strong transition-all">
                <h3 className="font-semibold mb-2">{faq.q}</h3>
                <p className="text-sm text-muted-foreground">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Final CTA */}
        <div className="max-w-2xl mx-auto text-center scale-in delay-900">
          <div className="glass-strong rounded-3xl p-10 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 pointer-events-none" />

            <div className="relative z-10">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to fix your operations?</h2>
              <p className="text-muted-foreground mb-8">14 days. Measurable results. Or your money back.</p>
              <Button size="lg" className="h-14 px-10 rounded-xl text-base shadow-lg shadow-primary/25">
                Start Your 14-Day Pilot
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <p className="text-xs text-muted-foreground mt-4">€997 one-time • First wins in 48 hours</p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border/50 py-8 mt-12 backdrop-blur-xl bg-background/80">
        <div className="container mx-auto px-6 text-center text-sm text-muted-foreground">
          <p>OARC Digital - Business Operations Intelligence</p>
        </div>
      </footer>
    </div>
  )
}
