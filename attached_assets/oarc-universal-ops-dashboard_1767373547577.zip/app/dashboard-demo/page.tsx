"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { verticals, calculateTotalImpact, type Problem } from "@/lib/demo-data"
import { ArrowRight, ArrowLeft, ChevronRight, Clock, Lightbulb, Brain } from "lucide-react"
import { ParticleBackground } from "@/components/particles"

export default function DashboardDemo() {
  const [selectedVertical, setSelectedVertical] = useState(verticals[0].id)
  const [selectedProblem, setSelectedProblem] = useState<Problem | null>(null)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const vertical = verticals.find((v) => v.id === selectedVertical)!
  const totalImpact = calculateTotalImpact(vertical.problems)

  return (
    <div className="min-h-screen bg-background relative">
      <ParticleBackground />

      {/* Ambient background */}
      <div className="fixed inset-0 bg-gradient-radial pointer-events-none" />
      <div className="fixed inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

      {/* Header */}
      <header className="relative z-10 border-b border-border/50 sticky top-0 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link
              href="/"
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span className="text-sm hidden sm:inline">Home</span>
            </Link>
            <div className="h-6 w-px bg-border" />
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-primary/20 flex items-center justify-center">
                <div className="w-3 h-3 rounded-sm bg-primary" />
              </div>
              <span className="font-semibold">OARC Intelligence</span>
            </div>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/10 text-xs text-amber-600 dark:text-amber-400 border border-amber-500/20">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-400"></span>
            </span>
            Live Demo
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-6 py-8 md:py-12">
        {/* Industry Selector */}
        <div className={`mb-8 ${mounted ? "fade-in-up" : "opacity-0"}`}>
          <div className="text-center mb-8 max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-balance">
              What should you fix <span className="text-gradient">right now</span>?
            </h1>
            <p className="text-lg text-muted-foreground">
              Select your industry. Get instant answers backed by data and behavioral science.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            {verticals.map((v, i) => (
              <button
                key={v.id}
                onClick={() => {
                  setSelectedVertical(v.id)
                  setSelectedProblem(null)
                }}
                className={`
                  flex items-center gap-3 px-6 py-3.5 rounded-xl text-sm font-medium transition-all
                  ${mounted ? "fade-in" : "opacity-0"}
                  ${
                    selectedVertical === v.id
                      ? "bg-primary text-primary-foreground shadow-xl shadow-primary/30 scale-105"
                      : "glass hover:glass-strong hover:scale-105"
                  }
                `}
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <span className="text-xl">{v.icon}</span>
                <span>{v.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-5xl mx-auto">
          {/* Summary Bar */}
          <div className={`mb-8 glass-strong rounded-2xl p-6 ${mounted ? "fade-in-up delay-200" : "opacity-0"}`}>
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Your {vertical.name} business is losing</p>
                <p className="text-4xl font-bold text-destructive">
                  {new Intl.NumberFormat("en-EU", {
                    style: "currency",
                    currency: "EUR",
                    maximumFractionDigits: 0,
                  }).format(totalImpact)}
                  <span className="text-xl text-muted-foreground font-normal">/month</span>
                </p>
              </div>
              <div className="flex items-center gap-6 text-center">
                <div>
                  <p className="text-3xl font-bold text-primary">{vertical.problems.length}</p>
                  <p className="text-xs text-muted-foreground">issues identified</p>
                </div>
                <div className="h-10 w-px bg-border" />
                <div>
                  <p className="text-3xl font-bold text-primary">
                    {vertical.problems.reduce((sum, p) => sum + p.solutions.length, 0)}
                  </p>
                  <p className="text-xs text-muted-foreground">solutions ready</p>
                </div>
              </div>
            </div>
          </div>

          <div className={`mb-6 ${mounted ? "fade-in-up delay-300" : "opacity-0"}`}>
            <h2 className="text-2xl font-bold mb-2">Your Priority Actions</h2>
            <p className="text-muted-foreground">Click any issue to see why it's happening and how to fix it</p>
          </div>

          {/* Problems List */}
          <div className="space-y-4 mb-12">
            {vertical.problems.map((problem, index) => (
              <button
                key={problem.id}
                onClick={() => setSelectedProblem(selectedProblem?.id === problem.id ? null : problem)}
                className={`
                    w-full text-left glass rounded-2xl p-6 transition-all group relative overflow-hidden
                    ${mounted ? "fade-in-up" : "opacity-0"}
                    ${selectedProblem?.id === problem.id ? "ring-2 ring-primary bg-card shadow-xl" : "hover:glass-strong hover:shadow-lg hover:scale-[1.01]"}
                  `}
                style={{ animationDelay: `${400 + index * 60}ms` }}
              >
                {/* Hover glow effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />

                <div className="relative z-10">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-3">
                        <span className="flex-shrink-0 w-8 h-8 rounded-lg bg-primary/10 text-primary text-sm font-bold flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                          {index + 1}
                        </span>
                        <h3 className="font-bold text-xl">{problem.title}</h3>
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {selectedProblem?.id === problem.id ? problem.insight : problem.insight.slice(0, 140) + "..."}
                      </p>
                    </div>
                    <div className="flex-shrink-0 text-right">
                      <p className="text-2xl font-bold text-destructive">
                        {new Intl.NumberFormat("en-EU", {
                          style: "currency",
                          currency: "EUR",
                          maximumFractionDigits: 0,
                        }).format(problem.monthlyImpact)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">lost monthly</p>
                    </div>
                  </div>

                  {/* Expanded Content */}
                  {selectedProblem?.id === problem.id && (
                    <div className="mt-6 pt-6 border-t border-border/50 space-y-6 animate-in fade-in slide-in-from-top-2 duration-300">
                      {/* Psychology Insight */}
                      <div className="flex gap-4 p-5 rounded-xl bg-muted/50 border border-border/50">
                        <Brain className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-2">
                            Why This Happens
                          </p>
                          <p className="text-sm leading-relaxed">{problem.psychology}</p>
                        </div>
                      </div>

                      {/* Solutions */}
                      <div>
                        <div className="flex items-center gap-2 mb-4">
                          <Lightbulb className="h-5 w-5 text-primary" />
                          <p className="text-sm font-semibold">How to Fix It</p>
                        </div>
                        <div className="space-y-3">
                          {problem.solutions.map((solution, i) => (
                            <div
                              key={i}
                              className="flex items-center justify-between gap-4 p-4 rounded-xl bg-background/50 border border-border/50 hover:bg-background hover:border-primary/30 transition-all group/solution"
                            >
                              <div className="flex items-center gap-3 min-w-0 flex-1">
                                <ChevronRight className="h-4 w-4 text-primary flex-shrink-0 group-hover/solution:translate-x-0.5 transition-transform" />
                                <span className="text-sm font-medium">{solution.title}</span>
                              </div>
                              <div className="flex items-center gap-4 flex-shrink-0">
                                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                                  <Clock className="h-3.5 w-3.5" />
                                  {solution.timeframe}
                                </div>
                                <span className="text-xs font-semibold text-primary px-2 py-1 rounded-md bg-primary/10">
                                  {solution.impact}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* Bottom CTA */}
          <div className={`glass-strong rounded-2xl p-8 text-center ${mounted ? "fade-in-up delay-600" : "opacity-0"}`}>
            <h3 className="text-2xl font-bold mb-3">Ready to implement these solutions?</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Our 14-day pilot program delivers measurable results with your actual data. If we don't improve your
              operations, it's completely free.
            </p>
            <Button asChild size="lg" className="rounded-xl h-12 px-8 shadow-lg shadow-primary/25">
              <Link href="/offer">
                Start Your 14-Day Pilot
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
