import CTASections from '../CTASections';

export default function CTASectionsExample() {
  return <CTASections />;
}
