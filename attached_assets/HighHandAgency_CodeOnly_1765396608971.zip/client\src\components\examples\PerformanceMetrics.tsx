import PerformanceMetrics from '../PerformanceMetrics';

export default function PerformanceMetricsExample() {
  return <PerformanceMetrics />;
}
