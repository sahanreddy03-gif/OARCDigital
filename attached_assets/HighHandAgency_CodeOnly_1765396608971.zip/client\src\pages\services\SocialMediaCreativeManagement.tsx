import { Button } from "@/components/ui/button";
import Layout from "@/components/layout/Layout";
import SEOHead from "@/components/SEOHead";
import { creativeServicesSEO } from "@/data/seoMetadata";
import { createServiceSchema } from "@/utils/structuredData";
import { useEffect, useState, useRef, useCallback } from "react";
import { Link } from "wouter";
import { motion, useReducedMotion, useInView, useSpring, useMotionValue, AnimatePresence } from "framer-motion";
import { 
  ArrowRight, CheckCircle2, Zap, BarChart3, Wand2, Network,
  Instagram, Sparkles, Brain, Rocket, TrendingUp, Play, Eye,
  Heart, MessageCircle, Share2, Palette, Camera, Video, Layers,
  Target, Users, LineChart, MousePointer2
} from "lucide-react";
import { SiTiktok, SiYoutube, SiX, SiThreads, SiLinkedin, SiMeta } from "react-icons/si";

import colorfulGymImg from "@assets/generated_images/colorful_modern_gym_interior.png";
import colorfulPerfumeImg from "@assets/generated_images/colorful_luxury_perfume_product.png";
import colorfulBeautyImg from "@assets/generated_images/colorful_natural_beauty_products.png";
import homecraftHeroImg from "@assets/pexels-shvetsa-12673974_1764638693005.jpg";
import heroVideo from "@assets/SnapInsta.to_AQMfI7sCSVLU8tLxyZLjxlyaGvnAjtYAkNpyBEIAox0m6TApwOZNnf5Y2rfuYUhoqYXMDubqUVXcJjUk8q57WHMBNJrUR_W4lUx94QM_1764630517873.mp4";
import tiktokVideo from "@assets/55555_1764634237326.mp4";
import aiFingerImg from "@assets/680fadb5aa40ab58ab98c0e5_AI-Experiencie-Agent-1_1764633229625.webp";
import linkedinPortraitImg from "@assets/pexels-weijia-ma-322731568-19989608_1764635510034.jpg";

import brandLogo1 from "@assets/stock_images/corporate_brand_logo_7fa71d75.jpg";
import brandLogo2 from "@assets/stock_images/corporate_brand_logo_3ecd3c3a.jpg";
import brandLogo3 from "@assets/stock_images/corporate_brand_logo_53ee2baf.jpg";
import brandLogo4 from "@assets/stock_images/corporate_brand_logo_36956200.jpg";
import brandLogo5 from "@assets/stock_images/corporate_brand_logo_fa7a9043.jpg";
import brandLogo6 from "@assets/stock_images/corporate_brand_logo_45511c03.jpg";

import organicSocialImg from "@assets/generated_images/social_media_creators_marketing_image.png";
import paidAdsImg from "@assets/stock_images/professional_ad_crea_01a208c3.jpg";
import contentCreationImg from "@assets/generated_images/Video_Production_Service_f2c7300b.png";
import influencerImg from "@assets/stock_images/social_media_creativ_8b2d8cae.jpg";

function AnimatedCounter({ value, suffix = "", prefix = "", duration = 2 }: { 
  value: number; 
  suffix?: string; 
  prefix?: string;
  duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const prefersReducedMotion = useReducedMotion();
  
  const motionValue = useMotionValue(0);
  const springValue = useSpring(motionValue, {
    damping: 50,
    stiffness: 100
  });
  
  const [displayValue, setDisplayValue] = useState(0);
  
  useEffect(() => {
    if (isInView && !prefersReducedMotion) {
      motionValue.set(value);
    } else if (prefersReducedMotion || isInView) {
      setDisplayValue(value);
    }
  }, [isInView, value, motionValue, prefersReducedMotion]);
  
  useEffect(() => {
    const unsubscribe = springValue.on("change", (latest) => {
      setDisplayValue(Math.round(latest));
    });
    return unsubscribe;
  }, [springValue]);
  
  return (
    <span ref={ref}>
      {prefix}{displayValue.toLocaleString()}{suffix}
    </span>
  );
}

function MagneticButton({ children, className, ...props }: React.ComponentProps<typeof motion.button>) {
  const ref = useRef<HTMLButtonElement>(null);
  const prefersReducedMotion = useReducedMotion();
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLButtonElement>) => {
    if (prefersReducedMotion || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const deltaX = (e.clientX - centerX) * 0.15;
    const deltaY = (e.clientY - centerY) * 0.15;
    x.set(deltaX);
    y.set(deltaY);
  }, [prefersReducedMotion, x, y]);
  
  const handleMouseLeave = useCallback(() => {
    x.set(0);
    y.set(0);
  }, [x, y]);
  
  return (
    <motion.button
      ref={ref}
      style={{ x, y }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={className}
      transition={{ type: "spring", stiffness: 150, damping: 15 }}
      {...props}
    >
      {children}
    </motion.button>
  );
}

function FloatingParticle({ delay, duration, color }: { delay: number; duration: number; color: string }) {
  return (
    <motion.div
      className="absolute rounded-full motion-reduce:hidden"
      style={{
        width: Math.random() * 8 + 4,
        height: Math.random() * 8 + 4,
        left: `${Math.random() * 100}%`,
        top: `${Math.random() * 100}%`,
        background: color,
      }}
      animate={{
        y: [-20, 20, -20],
        x: [-10, 10, -10],
        opacity: [0.3, 0.8, 0.3],
        scale: [1, 1.2, 1],
      }}
      transition={{
        duration,
        delay,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    />
  );
}

function CreativeFlowDiagram({ steps, gradient }: { steps: { icon: React.ReactNode; label: string }[]; gradient: string }) {
  const prefersReducedMotion = useReducedMotion();
  
  return (
    <div className="flex items-center justify-center gap-2 mt-6">
      {steps.map((step, idx) => (
        <div key={idx} className="flex items-center gap-2">
          <motion.div 
            className={`w-12 h-12 rounded-xl ${gradient} flex items-center justify-center shadow-lg`}
            initial={prefersReducedMotion ? {} : { scale: 0.8, opacity: 0 }}
            whileInView={prefersReducedMotion ? {} : { scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={prefersReducedMotion ? {} : { delay: idx * 0.15 }}
            whileHover={prefersReducedMotion ? {} : { scale: 1.1, rotate: 5 }}
          >
            {step.icon}
          </motion.div>
          <span className="text-xs font-semibold text-white/80 hidden sm:block">{step.label}</span>
          {idx < steps.length - 1 && (
            <motion.div
              className="w-6 h-0.5 bg-white/30"
              initial={prefersReducedMotion ? {} : { scaleX: 0 }}
              whileInView={prefersReducedMotion ? {} : { scaleX: 1 }}
              viewport={{ once: true }}
              transition={prefersReducedMotion ? {} : { delay: idx * 0.15 + 0.1 }}
            />
          )}
        </div>
      ))}
    </div>
  );
}

function CreativePortfolioCard({ image, title, platform, metrics, color, delay }: {
  image: string;
  title: string;
  platform: string;
  metrics: { views: string; engagement: string };
  color: string;
  delay: number;
}) {
  const prefersReducedMotion = useReducedMotion();
  
  return (
    <motion.div
      className="relative group cursor-pointer"
      initial={prefersReducedMotion ? {} : { opacity: 0, y: 30 }}
      whileInView={prefersReducedMotion ? {} : { opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={prefersReducedMotion ? {} : { delay }}
      whileHover={prefersReducedMotion ? {} : { y: -8 }}
    >
      <div className={`absolute inset-0 ${color} rounded-2xl blur-xl opacity-0 group-hover:opacity-50 transition-opacity motion-reduce:hidden`} />
      <div className="relative bg-white rounded-2xl overflow-hidden shadow-xl group-hover:shadow-2xl transition-all duration-300">
        <div className="aspect-[4/5] relative overflow-hidden">
          <img 
            src={image} 
            alt={title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="absolute bottom-4 left-4 right-4">
              <div className="flex items-center gap-2 mb-2">
                <span className={`px-2 py-1 text-xs font-bold text-white rounded-full ${color}`}>{platform}</span>
              </div>
              <p className="text-white font-bold text-sm">{title}</p>
              <div className="flex items-center gap-4 mt-2 text-white/80 text-xs">
                <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {metrics.views}</span>
                <span className="flex items-center gap-1"><Heart className="w-3 h-3" /> {metrics.engagement}</span>
              </div>
            </div>
          </div>
          <div className="absolute top-4 right-4 w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <Play className="w-5 h-5 text-white fill-white" />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

interface PillarCardData {
  id: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  cta: string;
  link: string;
  image: string;
  overlayGradient: string;
  ctaStyle: {
    background: string;
    border: string;
    boxShadow: string;
    hoverBackground: string;
    hoverBorder: string;
    hoverShadow: string;
  };
}

function PillarCard({ card, idx }: { card: PillarCardData; idx: number }) {
  const prefersReducedMotion = useReducedMotion();
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <motion.div 
      key={card.id}
      initial={prefersReducedMotion ? {} : { opacity: 0, y: 30 }}
      whileInView={prefersReducedMotion ? {} : { opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={prefersReducedMotion ? {} : { delay: idx * 0.15, duration: 0.6 }}
      whileHover={prefersReducedMotion ? {} : { y: -12 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="relative h-[480px] md:h-[520px] rounded-3xl overflow-hidden cursor-pointer shadow-[0_4px_24px_rgba(0,0,0,0.3)] hover:shadow-[0_32px_64px_rgba(0,0,0,0.5)] transition-shadow duration-500"
      data-testid={`card-pillar-${card.id}`}
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-[1]">
        <motion.img 
          src={card.image}
          alt={`${card.title} - premium marketing service`}
          className="w-full h-full object-cover object-center"
          animate={prefersReducedMotion ? {} : { scale: isHovered ? 1.05 : 1 }}
          transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
          loading="eager"
        />
      </div>
      
      {/* Elite Gradient Overlay */}
      <div 
        className="absolute inset-0 z-[2]"
        style={{ background: card.overlayGradient }}
      />
      
      {/* Card Content - Positioned at Bottom */}
      <div className="relative z-[3] h-full p-8 md:p-10 flex flex-col justify-end">
        {/* Icon */}
        <motion.div 
          className="text-[40px] mb-5 drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)]"
          animate={prefersReducedMotion ? {} : { scale: isHovered ? 1.1 : 1 }}
          transition={{ duration: 0.3 }}
        >
          <card.icon className="w-10 h-10 md:w-12 md:h-12 text-white" />
        </motion.div>
        
        {/* Title */}
        <h3 
          className="text-3xl md:text-4xl font-extrabold text-white mb-4 tracking-tight"
          style={{ 
            fontFamily: 'Inter, system-ui, -apple-system, sans-serif',
            textShadow: '0 4px 16px rgba(0, 0, 0, 0.6)',
            letterSpacing: '-0.5px'
          }}
        >
          {card.title}
        </h3>
        
        {/* Description */}
        <p 
          className="text-base md:text-[17px] text-white/95 mb-7 leading-relaxed max-w-[90%]"
          style={{ 
            fontFamily: 'Inter, system-ui, -apple-system, sans-serif',
            textShadow: '0 2px 12px rgba(0, 0, 0, 0.5)'
          }}
        >
          {card.description}
        </p>
        
        {/* CTA Button - Elite Styling */}
        <Link href={card.link}>
          <motion.span
            className="inline-flex items-center gap-2.5 px-7 py-4 rounded-xl text-white font-semibold text-[15px] w-fit cursor-pointer transition-all duration-300"
            style={{ 
              fontFamily: 'Inter, system-ui, -apple-system, sans-serif',
              background: isHovered ? card.ctaStyle.hoverBackground : card.ctaStyle.background,
              border: isHovered ? `1.5px solid ${card.ctaStyle.hoverBorder}` : card.ctaStyle.border,
              boxShadow: isHovered ? card.ctaStyle.hoverShadow : card.ctaStyle.boxShadow,
              letterSpacing: '0.3px',
              transform: isHovered ? 'translateX(6px)' : 'translateX(0)'
            }}
            data-testid={`button-cta-${card.id}`}
          >
            {card.cta}
            <motion.span
              animate={{ x: isHovered ? 4 : 0 }}
              transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
            >
              <ArrowRight className="w-4 h-4" />
            </motion.span>
          </motion.span>
        </Link>
      </div>
    </motion.div>
  );
}

export default function SocialMediaCreativeManagement() {
  const prefersReducedMotion = useReducedMotion();
  const [activeCard, setActiveCard] = useState(0);
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  useEffect(() => {
    if (prefersReducedMotion) return;
    const interval = setInterval(() => {
      setActiveCard(prev => (prev + 1) % 4);
    }, 4000);
    return () => clearInterval(interval);
  }, [prefersReducedMotion]);
  
  const fadeIn = prefersReducedMotion ? {} : { opacity: 0, y: 20 };
  const fadeInVisible = prefersReducedMotion ? {} : { opacity: 1, y: 0 };

  const pillarCards = [
    {
      id: "organic",
      title: "Organic Social",
      icon: Brain,
      description: "Content engineered for algorithms & audiences",
      cta: "Explore Organic",
      link: "/services/social",
      image: organicSocialImg,
      overlayGradient: "linear-gradient(to top, rgba(107, 33, 168, 0.92) 0%, rgba(88, 28, 135, 0.75) 50%, rgba(88, 28, 135, 0.4) 75%, transparent 100%)",
      ctaStyle: {
        background: "rgba(168, 85, 247, 0.25)",
        border: "1.5px solid rgba(168, 85, 247, 0.5)",
        boxShadow: "0 8px 24px rgba(168, 85, 247, 0.2)",
        hoverBackground: "rgba(168, 85, 247, 0.4)",
        hoverBorder: "rgba(168, 85, 247, 0.8)",
        hoverShadow: "0 12px 32px rgba(168, 85, 247, 0.35)"
      }
    },
    {
      id: "paid",
      title: "Paid Advertising",
      icon: TrendingUp,
      description: "Campaigns built to scale, not just spend",
      cta: "Explore Paid Ads",
      link: "/services/paid-advertising",
      image: paidAdsImg,
      overlayGradient: "linear-gradient(to top, rgba(131, 24, 67, 0.92) 0%, rgba(157, 23, 77, 0.75) 50%, rgba(157, 23, 77, 0.4) 75%, transparent 100%)",
      ctaStyle: {
        background: "rgba(219, 39, 119, 0.25)",
        border: "1.5px solid rgba(219, 39, 119, 0.5)",
        boxShadow: "0 8px 24px rgba(219, 39, 119, 0.2)",
        hoverBackground: "rgba(219, 39, 119, 0.4)",
        hoverBorder: "rgba(219, 39, 119, 0.8)",
        hoverShadow: "0 12px 32px rgba(219, 39, 119, 0.35)"
      }
    },
    {
      id: "content",
      title: "Content Creation",
      icon: Video,
      description: "Production-quality content at social-speed delivery",
      cta: "Explore Content",
      link: "/services/creative",
      image: contentCreationImg,
      overlayGradient: "linear-gradient(to top, rgba(194, 65, 12, 0.92) 0%, rgba(154, 52, 18, 0.75) 50%, rgba(154, 52, 18, 0.4) 75%, transparent 100%)",
      ctaStyle: {
        background: "rgba(234, 88, 12, 0.25)",
        border: "1.5px solid rgba(234, 88, 12, 0.5)",
        boxShadow: "0 8px 24px rgba(234, 88, 12, 0.2)",
        hoverBackground: "rgba(234, 88, 12, 0.4)",
        hoverBorder: "rgba(234, 88, 12, 0.8)",
        hoverShadow: "0 12px 32px rgba(234, 88, 12, 0.35)"
      }
    },
    {
      id: "influencer",
      title: "Influencer Marketing",
      icon: Users,
      description: "Vetted creators who amplify your message authentically",
      cta: "Explore Influencer",
      link: "/services/influencer-marketing",
      image: influencerImg,
      overlayGradient: "linear-gradient(to top, rgba(4, 120, 87, 0.92) 0%, rgba(6, 95, 70, 0.75) 50%, rgba(6, 95, 70, 0.4) 75%, transparent 100%)",
      ctaStyle: {
        background: "rgba(16, 185, 129, 0.25)",
        border: "1.5px solid rgba(16, 185, 129, 0.5)",
        boxShadow: "0 8px 24px rgba(16, 185, 129, 0.2)",
        hoverBackground: "rgba(16, 185, 129, 0.4)",
        hoverBorder: "rgba(16, 185, 129, 0.8)",
        hoverShadow: "0 12px 32px rgba(16, 185, 129, 0.35)"
      }
    }
  ];

  const platformIcons = [
    { Icon: SiMeta, label: "Meta Ads", color: "#1877F2" },
    { Icon: Instagram, label: "Instagram", color: "#E4405F" },
    { Icon: SiTiktok, label: "TikTok", color: "#000000" },
    { Icon: SiYoutube, label: "YouTube", color: "#FF0000" },
    { Icon: SiLinkedin, label: "LinkedIn", color: "#0A66C2" },
    { Icon: SiX, label: "X", color: "#000000" },
    { Icon: SiThreads, label: "Threads", color: "#000000" }
  ];

  const brandLogos = [
    brandLogo1, brandLogo2, brandLogo3, brandLogo4, brandLogo5, brandLogo6
  ];

  const portfolioItems = [
    { image: colorfulGymImg, title: "FitnessPro Social Growth", platform: "Instagram", metrics: { views: "15M", engagement: "18.7%" }, color: "bg-zinc-800" },
    { image: colorfulPerfumeImg, title: "Luxe Essence Launch", platform: "TikTok", metrics: { views: "59M", engagement: "12.3%" }, color: "bg-zinc-800" },
    { image: colorfulBeautyImg, title: "NaturalCare Community", platform: "YouTube", metrics: { views: "420K", engagement: "24.5%" }, color: "bg-zinc-800" },
    { image: homecraftHeroImg, title: "HomeCraft E-commerce", platform: "LinkedIn", metrics: { views: "280%", engagement: "ROI" }, color: "bg-zinc-800" },
  ];

  const useCases = [
    {
      id: "ecommerce",
      title: "E-commerce Disruptors",
      description: "We've scaled 47+ e-commerce brands from €10K to €1M+ monthly revenue.",
      points: ["Predictive audience discovery", "Dynamic product creative", "Malta Edge: EU-compliant scaling"],
      color: "from-[#FF6B9D] to-[#C77DFF]"
    },
    {
      id: "dtc",
      title: "DTC Challengers",
      description: "Our OARC Launch Protocol gets brands to profitability in 90 days.",
      points: ["90-day launch framework", "Founder-led content", "Malta Edge: Access to EU markets"],
      color: "from-[#FF6B53] to-[#FF9F7F]"
    },
    {
      id: "saas",
      title: "B2B SaaS",
      description: "Turn complex products into compelling stories. Based on client averages.",
      points: ["LinkedIn thought leadership", "Product demos", "Malta Edge: Multilingual campaigns"],
      color: "from-[#4F46E5] to-[#818CF8]"
    },
    {
      id: "lifestyle",
      title: "Premium Lifestyle",
      description: "Aspirational brand narratives that command premium pricing.",
      points: ["Luxury positioning", "Editorial content", "Malta Edge: Mediterranean aesthetics"],
      color: "from-[#7B2FF7] to-[#C77DFF]"
    },
    {
      id: "finance",
      title: "FinTech & iGaming",
      description: "Malta's financial hub demands compliance expertise. We deliver.",
      points: ["Regulatory-compliant creative", "Risk-managed targeting", "Malta Edge: MGA/MFSA expertise"],
      color: "from-[#10B981] to-[#34D399]"
    },
    {
      id: "enterprise",
      title: "Global Enterprise",
      description: "Unified brand experiences across 30+ markets worldwide.",
      points: ["Multi-market coordination", "AI localization", "Malta Edge: EU HQ advantage"],
      color: "from-[#F59E0B] to-[#FBBF24]"
    }
  ];

  return (
    <Layout>
      <SEOHead
        title="AI-Powered Marketing Services | Revenue, Creative & Growth | OARC Digital Malta"
        description="Malta's leading AI marketing agency. We engineer revenue systems, not just campaigns. Explore our AI-powered social, creative lab, and creator network services."
        canonicalUrl="https://oarcdigital.com/services/how-we-help"
        ogType="article"
        structuredData={createServiceSchema(
          "AI-Powered Marketing Services",
          "OARC Digital delivers AI-engineered marketing solutions including revenue automation, creative production, and influencer partnerships from Malta.",
          "AI Marketing Services"
        )}
        schemaId="service-marketing-overview"
      />

      {/* HERO SECTION 1: ANIMATIONS ABOVE THE FOLD */}
      {/* Mobile: Content aligned to TOP | Desktop: Vertically centered */}
      <section className="relative min-h-screen flex flex-col justify-start md:justify-center overflow-hidden bg-[#FDFCFA]">
        {/* Premium Light Background with Subtle Texture */}
        <div className="absolute inset-0 opacity-[0.02] pointer-events-none"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
          }}
        />

        {/* Subtle Video Background with light overlay */}
        <div className="absolute inset-0 motion-reduce:hidden">
          <video 
            autoPlay 
            loop 
            muted 
            playsInline
            preload="metadata"
            className="absolute inset-0 w-full h-full object-cover opacity-15"
            style={{ filter: 'grayscale(30%) brightness(1.2)' }}
          >
            <source src="https://videos.pexels.com/video-files/856106/856106-hd_1920_1080_30fps.mp4" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-gradient-to-b from-[#FDFCFA]/80 via-[#FDFCFA]/60 to-[#FDFCFA]/95" />
        </div>

        {/* TARGET CIRCLE with SVG ICONS - Positioned for new layout */}
        {/* Mobile: Top-right beside title (below header) | Desktop: Right side, lifted higher to avoid text overlap */}
        <div className="absolute top-20 right-1 sm:top-20 sm:right-3 md:top-[30%] md:right-12 lg:right-20 md:-translate-y-1/2 w-[136px] h-[136px] sm:w-40 sm:h-40 md:w-56 md:h-56 lg:w-72 lg:h-72 motion-reduce:hidden pointer-events-none z-10">
          <svg width="100%" height="100%" viewBox="0 0 300 300" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="centerGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FF6B9D"/>
                <stop offset="100%" stopColor="#FF8FAB"/>
              </linearGradient>
              <filter id="glow1" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="3" result="blur"/>
                <feMerge>
                  <feMergeNode in="blur"/>
                  <feMergeNode in="SourceGraphic"/>
                </feMerge>
              </filter>
              <filter id="shadowFilter">
                <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.2"/>
              </filter>
            </defs>
            
            {/* Pink Target Center with Crosshair */}
            <circle cx="150" cy="150" r="28" fill="url(#centerGrad)" filter="url(#glow1)">
              <animate attributeName="r" values="26;30;26" dur="2s" repeatCount="indefinite"/>
            </circle>
            <circle cx="150" cy="150" r="22" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="2"/>
            
            {/* Crosshair Lines - Dashed, extending outward */}
            <line x1="150" y1="100" x2="150" y2="125" stroke="rgba(255,143,171,0.7)" strokeWidth="2" strokeDasharray="4 3">
              <animate attributeName="stroke-dashoffset" from="0" to="7" dur="0.8s" repeatCount="indefinite"/>
            </line>
            <line x1="150" y1="175" x2="150" y2="200" stroke="rgba(255,143,171,0.7)" strokeWidth="2" strokeDasharray="4 3">
              <animate attributeName="stroke-dashoffset" from="0" to="7" dur="0.8s" repeatCount="indefinite"/>
            </line>
            <line x1="100" y1="150" x2="125" y2="150" stroke="rgba(255,143,171,0.7)" strokeWidth="2" strokeDasharray="4 3">
              <animate attributeName="stroke-dashoffset" from="0" to="7" dur="0.8s" repeatCount="indefinite"/>
            </line>
            <line x1="175" y1="150" x2="200" y2="150" stroke="rgba(255,143,171,0.7)" strokeWidth="2" strokeDasharray="4 3">
              <animate attributeName="stroke-dashoffset" from="0" to="7" dur="0.8s" repeatCount="indefinite"/>
            </line>
            
            {/* ROTATING ICONS GROUP */}
            <g>
              <animateTransform attributeName="transform" type="rotate" from="0 150 150" to="360 150 150" dur="12s" repeatCount="indefinite"/>
              
              {/* Pink Speech Bubble with Heart - Top */}
              <g transform="translate(125, 35)" filter="url(#shadowFilter)">
                <rect x="0" y="5" width="50" height="38" rx="12" fill="#FF6B9D"/>
                <polygon points="18,43 25,52 32,43" fill="#FF6B9D"/>
                <path d="M25 32 Q 17 26 14 20 Q 11 14 17 10 Q 23 6 25 14 Q 27 6 33 10 Q 39 14 36 20 Q 33 26 25 32" fill="white"/>
                <animateTransform attributeName="transform" type="rotate" from="0 25 25" to="-360 25 25" dur="12s" repeatCount="indefinite" additive="sum"/>
              </g>
              
              {/* Purple Speech Bubble with Dots - KEEP THIS ONE - Bottom Left */}
              <g transform="translate(50, 195)" filter="url(#shadowFilter)">
                <rect x="0" y="0" width="44" height="32" rx="9" fill="#A855F7"/>
                <polygon points="30,32 35,42 40,32" fill="#A855F7"/>
                <circle cx="12" cy="16" r="4" fill="white"/>
                <circle cx="22" cy="16" r="4" fill="white"/>
                <circle cx="32" cy="16" r="4" fill="white"/>
                <animateTransform attributeName="transform" type="rotate" from="0 22 18" to="-360 22 18" dur="12s" repeatCount="indefinite" additive="sum"/>
              </g>
              
              {/* Blue Share Arrow Speech Bubble - Right */}
              <g transform="translate(220, 120)" filter="url(#shadowFilter)">
                <rect x="0" y="5" width="44" height="34" rx="10" fill="#3B82F6"/>
                <polygon points="15,39 20,48 25,39" fill="#3B82F6"/>
                <path d="M30 15 L20 22 L20 18 L12 18 L12 28 L20 28 L20 24 L30 31 L30 15" fill="white" stroke="white" strokeWidth="1" strokeLinejoin="round"/>
                <animateTransform attributeName="transform" type="rotate" from="0 22 22" to="-360 22 22" dur="12s" repeatCount="indefinite" additive="sum"/>
              </g>
              
              {/* Yellow Winking Smiley - Bottom Right */}
              <g transform="translate(180, 215)" filter="url(#shadowFilter)">
                <circle cx="22" cy="22" r="22" fill="#FBBF24"/>
                <circle cx="14" cy="18" r="3" fill="#1F2937"/>
                <line x1="26" y1="16" x2="32" y2="20" stroke="#1F2937" strokeWidth="3" strokeLinecap="round"/>
                <path d="M12 28 Q 22 36 32 28" fill="none" stroke="#1F2937" strokeWidth="3" strokeLinecap="round"/>
                <animateTransform attributeName="transform" type="rotate" from="0 22 22" to="-360 22 22" dur="12s" repeatCount="indefinite" additive="sum"/>
              </g>
              
              {/* Yellow Hashtag Speech Bubble - Left */}
              <g transform="translate(30, 115)" filter="url(#shadowFilter)">
                <rect x="0" y="5" width="48" height="36" rx="10" fill="#FBBF24"/>
                <polygon points="32,41 36,50 40,41" fill="#FBBF24"/>
                <text x="24" y="30" textAnchor="middle" fill="white" fontSize="22" fontWeight="bold">#</text>
                <animateTransform attributeName="transform" type="rotate" from="0 24 23" to="-360 24 23" dur="12s" repeatCount="indefinite" additive="sum"/>
              </g>
              
              {/* Decorative Orange Circle - Top Right */}
              <g transform="translate(200, 60)">
                <circle cx="15" cy="15" r="15" fill="#FB923C">
                  <animate attributeName="r" values="14;17;14" dur="2.5s" repeatCount="indefinite"/>
                </circle>
                <animateTransform attributeName="transform" type="rotate" from="0 15 15" to="-360 15 15" dur="12s" repeatCount="indefinite" additive="sum"/>
              </g>
              
              {/* Small Yellow Circle - Top */}
              <g transform="translate(85, 50)">
                <circle cx="10" cy="10" r="10" fill="#FDE047">
                  <animate attributeName="opacity" values="0.8;1;0.8" dur="2s" repeatCount="indefinite"/>
                </circle>
                <animateTransform attributeName="transform" type="rotate" from="0 10 10" to="-360 10 10" dur="12s" repeatCount="indefinite" additive="sum"/>
              </g>
              
              {/* Small Pink Circle - Bottom Center */}
              <g transform="translate(130, 240)">
                <circle cx="10" cy="10" r="10" fill="#FF6B9D">
                  <animate attributeName="opacity" values="0.7;1;0.7" dur="2s" repeatCount="indefinite"/>
                </circle>
                <animateTransform attributeName="transform" type="rotate" from="0 10 10" to="-360 10 10" dur="12s" repeatCount="indefinite" additive="sum"/>
              </g>
              
              {/* Small Pink Dot - Far Right */}
              <g transform="translate(265, 165)">
                <circle cx="6" cy="6" r="6" fill="#F472B6">
                  <animate attributeName="opacity" values="0.5;1;0.5" dur="1.5s" repeatCount="indefinite"/>
                </circle>
              </g>
            </g>
          </svg>
        </div>

        {/* Animated Social Nodes SVG Overlay - Full Screen */}
        <div className="absolute inset-0 motion-reduce:hidden pointer-events-none z-20">
          <svg className="w-full h-full" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid slice">
            <defs>
              <filter id="softGlow">
                <feGaussianBlur stdDeviation="4" result="blur"/>
                <feMerge>
                  <feMergeNode in="blur"/>
                  <feMergeNode in="SourceGraphic"/>
                </feMerge>
              </filter>
            </defs>
            
            {/* AI Neural Network - Soft purple (visible on light background) */}
            {/* Connection Lines */}
            <motion.line 
              x1="200" y1="300" x2="500" y2="200" 
              stroke="#7B2FF7" 
              strokeWidth="2" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.15, 0.35, 0.15] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.line 
              x1="500" y1="200" x2="800" y2="150" 
              stroke="#7B2FF7" 
              strokeWidth="2" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.12, 0.3, 0.12] }}
              transition={{ duration: 3.5, delay: 0.3, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.line 
              x1="200" y1="300" x2="150" y2="500" 
              stroke="#7B2FF7" 
              strokeWidth="2" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.1, 0.28, 0.1] }}
              transition={{ duration: 4, delay: 0.5, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.line 
              x1="1600" y1="400" x2="1300" y2="600" 
              stroke="#7B2FF7" 
              strokeWidth="2" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.15, 0.35, 0.15] }}
              transition={{ duration: 3.2, delay: 0.2, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.line 
              x1="1300" y1="600" x2="1100" y2="450" 
              stroke="#7B2FF7" 
              strokeWidth="2" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.1, 0.28, 0.1] }}
              transition={{ duration: 4, delay: 0.8, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.line 
              x1="500" y1="200" x2="1100" y2="450" 
              stroke="#7B2FF7" 
              strokeWidth="1.5" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.08, 0.22, 0.08] }}
              transition={{ duration: 5, delay: 1, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.line 
              x1="150" y1="500" x2="400" y2="650" 
              stroke="#7B2FF7" 
              strokeWidth="2" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.1, 0.28, 0.1] }}
              transition={{ duration: 3.8, delay: 0.6, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.line 
              x1="400" y1="650" x2="700" y2="550" 
              stroke="#7B2FF7" 
              strokeWidth="1.5" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.08, 0.22, 0.08] }}
              transition={{ duration: 4.2, delay: 0.9, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.line 
              x1="800" y1="150" x2="1100" y2="450" 
              stroke="#7B2FF7" 
              strokeWidth="1.5" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.08, 0.2, 0.08] }}
              transition={{ duration: 4.5, delay: 0.4, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.line 
              x1="700" y1="550" x2="1100" y2="450" 
              stroke="#7B2FF7" 
              strokeWidth="1.5" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.08, 0.2, 0.08] }}
              transition={{ duration: 3.5, delay: 1.2, repeat: Infinity, ease: "easeInOut" }}
            />
            
            {/* Neural Network Nodes - Soft purple */}
            <motion.circle 
              cx="200" cy="300" r="8" 
              fill="#7B2FF7" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.2, 0.5, 0.2] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <motion.circle 
              cx="500" cy="200" r="7" 
              fill="#7B2FF7" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.18, 0.45, 0.18] }}
              transition={{ duration: 2.5, delay: 0.5, repeat: Infinity }}
            />
            <motion.circle 
              cx="150" cy="500" r="6" 
              fill="#7B2FF7" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.18, 0.42, 0.18] }}
              transition={{ duration: 3, delay: 1, repeat: Infinity }}
            />
            <motion.circle 
              cx="800" cy="150" r="7" 
              fill="#7B2FF7" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.15, 0.4, 0.15] }}
              transition={{ duration: 2, delay: 0.3, repeat: Infinity }}
            />
            <motion.circle 
              cx="1600" cy="400" r="8" 
              fill="#7B2FF7" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.2, 0.5, 0.2] }}
              transition={{ duration: 2.8, delay: 0.8, repeat: Infinity }}
            />
            <motion.circle 
              cx="1300" cy="600" r="7" 
              fill="#7B2FF7" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.18, 0.45, 0.18] }}
              transition={{ duration: 2.2, delay: 0.4, repeat: Infinity }}
            />
            <motion.circle 
              cx="1100" cy="450" r="7" 
              fill="#7B2FF7" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.15, 0.4, 0.15] }}
              transition={{ duration: 2.6, delay: 0.6, repeat: Infinity }}
            />
            <motion.circle 
              cx="400" cy="650" r="6" 
              fill="#7B2FF7" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.18, 0.42, 0.18] }}
              transition={{ duration: 3.2, delay: 0.7, repeat: Infinity }}
            />
            <motion.circle 
              cx="700" cy="550" r="6" 
              fill="#7B2FF7" 
              filter="url(#softGlow)"
              animate={{ opacity: [0.15, 0.38, 0.15] }}
              transition={{ duration: 2.4, delay: 1.1, repeat: Infinity }}
            />
            
            {/* Floating Speech Bubble - Top Left */}
            <motion.g 
              transform="translate(80, 150)"
              animate={{ y: [-8, 8, -8], opacity: [0.6, 1, 0.6] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <rect x="0" y="0" width="50" height="35" rx="8" fill="#7B2FF7" opacity="0.85"/>
              <polygon points="15,35 20,48 28,35" fill="#7B2FF7" opacity="0.85"/>
              <circle cx="14" cy="17" r="4" fill="white" opacity="0.9"/>
              <circle cx="26" cy="17" r="4" fill="white" opacity="0.9"/>
              <circle cx="38" cy="17" r="4" fill="white" opacity="0.9"/>
            </motion.g>
            
            {/* Floating Heart - Top Right */}
            <motion.g 
              transform="translate(1700, 180)"
              animate={{ scale: [1, 1.15, 1], opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <path d="M20,35 Q 10 28 6 20 Q 2 12 10 7 Q 18 2 20 12 Q 22 2 30 7 Q 38 12 34 20 Q 30 28 20 35" 
                    fill="#FF6B9D" 
                    opacity="0.85"
                    transform="scale(1.3)"
              />
            </motion.g>
            
            {/* +1 Engagement Bubble - Left */}
            <motion.g 
              transform="translate(300, 450)"
              animate={{ y: [5, -5, 5], scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <circle cx="20" cy="20" r="18" fill="#FFD700" opacity="0.85"/>
              <text x="20" y="26" textAnchor="middle" fill="white" fontSize="16" fontWeight="bold">+1</text>
            </motion.g>
          </svg>
        </div>
        
        {/* Floating Particles */}
        <div className="absolute inset-0 motion-reduce:hidden">
          {[...Array(20)].map((_, i) => (
            <FloatingParticle 
              key={i} 
              delay={i * 0.2} 
              duration={4 + Math.random() * 3}
              color={['#7B2FF7', '#FF6B9D', '#FF6B53', '#00D4FF', '#FFD700'][Math.floor(Math.random() * 5)]}
            />
          ))}
        </div>
        
        {/* Premium Decorative Glows - Softer for light background */}
        <motion.div 
          className="absolute top-10 left-5 w-48 h-48 rounded-full bg-gradient-to-r from-[#7B2FF7]/20 to-[#FF6B9D]/20 blur-3xl motion-reduce:hidden"
          animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute bottom-20 left-1/4 w-64 h-64 rounded-full bg-gradient-to-r from-[#FF6B53]/15 to-[#FF6B9D]/15 blur-3xl motion-reduce:hidden"
          animate={{ scale: [1.2, 1, 1.2], opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute top-1/3 left-1/3 w-40 h-40 rounded-full bg-[#00D4FF]/10 blur-2xl motion-reduce:hidden"
          animate={{ y: [-20, 20, -20], opacity: [0.15, 0.3, 0.15] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        />
        
        {/* Hero Content Area - MOBILE: Full-width stacked | DESKTOP: Two-column */}
        <div className="relative z-10 max-w-6xl mx-auto px-4 md:px-8 pt-20 pb-3 md:pt-6 md:pb-8">
          
          {/* MOBILE: Full-width stacked layout | DESKTOP: Two-column grid */}
          {/* More bottom margin to push portfolio cards down - mb-16 on mobile */}
          <div className="flex flex-col md:grid md:grid-cols-2 gap-3 md:gap-8 items-start md:items-center mb-16 md:mb-6">
            
            {/* Text Content - Full width on mobile, with room for target animation */}
            <div className="w-full text-left pr-[140px] sm:pr-40 md:pr-0">
              {/* Main Headline - Space Grotesk, clean and elegant */}
              <motion.div 
                initial={fadeIn}
                animate={fadeInVisible}
                transition={prefersReducedMotion ? {} : { delay: 0.1, duration: 0.5 }}
                className="mb-2 md:mb-3 leading-[0.85]"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {/* CREATIVE - Clean solid dark */}
                <span 
                  className="block font-bold text-[#1A1A1A]"
                  style={{ 
                    fontSize: 'clamp(3.25rem, 14vw, 4.5rem)',
                    letterSpacing: '-0.03em'
                  }}
                >
                  Creative
                </span>
                {/* That Converts - Clean accent color */}
                <span 
                  className="block font-bold text-[#7B2FF7]"
                  style={{ 
                    fontSize: 'clamp(2.5rem, 11vw, 3.5rem)',
                    letterSpacing: '-0.02em'
                  }}
                >
                  That Converts
                </span>
              </motion.div>
              
              {/* Small Tagline - Social Media Management */}
              <motion.p 
                initial={fadeIn}
                animate={fadeInVisible}
                transition={prefersReducedMotion ? {} : { delay: 0.15, duration: 0.5 }}
                className="text-xs sm:text-sm md:text-base uppercase tracking-widest font-medium text-[#525252] max-w-xs sm:max-w-md mb-3 md:mb-4"
                style={{ fontFamily: 'Inter, system-ui, -apple-system, sans-serif' }}
              >
                Social Media Management
              </motion.p>
              
              {/* Main Body Text - Readable modern sans-serif */}
              <motion.p 
                initial={fadeIn}
                animate={fadeInVisible}
                transition={prefersReducedMotion ? {} : { delay: 0.2, duration: 0.5 }}
                className="text-base sm:text-lg md:text-xl text-[#525252] max-w-xs sm:max-w-md mb-5 md:mb-6 leading-relaxed"
                style={{ fontFamily: 'Inter, system-ui, -apple-system, sans-serif' }}
              >
                We combine organic content, paid campaigns, production, and influencer partnerships into one integrated system that drives revenue—not just reach.
              </motion.p>
              
              {/* CTA Buttons - Larger on mobile, row on desktop */}
              <motion.div 
                initial={fadeIn}
                animate={fadeInVisible}
                transition={prefersReducedMotion ? {} : { delay: 0.3, duration: 0.5 }}
                className="flex flex-col sm:flex-row gap-2.5 sm:gap-3"
              >
                <Link href="/contact">
                  <MagneticButton
                    whileHover={prefersReducedMotion ? {} : { scale: 1.05, y: -2 }}
                    whileTap={prefersReducedMotion ? {} : { scale: 0.98 }}
                    className="group inline-flex items-center gap-2 bg-gradient-to-r from-[#7B2FF7] to-[#FF6B9D] text-white rounded-full px-5 py-3 sm:px-6 sm:py-3.5 text-sm sm:text-base font-bold shadow-lg shadow-purple-500/25 hover:shadow-xl hover:shadow-purple-500/35 transition-all"
                    data-testid="button-hero-cta"
                  >
                    Start Creating
                    <div className="w-7 h-7 sm:w-8 sm:h-8 bg-white/20 rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform">
                      <ArrowRight className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-white" />
                    </div>
                  </MagneticButton>
                </Link>
                <Link href="#portfolio">
                  <motion.button
                    whileHover={prefersReducedMotion ? {} : { scale: 1.05 }}
                    className="inline-flex items-center gap-2 bg-white border-2 border-[#E5E4E0] text-[#1A1A1A] rounded-full px-5 py-3 sm:px-6 sm:py-3.5 text-sm sm:text-base font-bold hover:border-[#7B2FF7]/30 hover:shadow-lg transition-all"
                    data-testid="button-view-work"
                  >
                    <Play className="w-4 h-4 sm:w-4 sm:h-4 fill-[#7B2FF7] text-[#7B2FF7]" />
                    View Work
                  </motion.button>
                </Link>
              </motion.div>
            </div>
          </div>
          
          {/* PORTFOLIO GALLERY - 3-column grid on mobile, 6-column on desktop */}
          <motion.div 
            id="portfolio"
            initial={fadeIn}
            animate={fadeInVisible}
            transition={prefersReducedMotion ? {} : { delay: 0.4, duration: 0.6 }}
            className="relative"
          >
            {/* Mobile: 3×2 Grid (TALLER cards) | Desktop: 6-column Grid */}
            <div className="grid grid-cols-3 md:grid-cols-6 gap-2.5 md:gap-3">
              {/* Card 1 - Instagram Post with AI Finger Image */}
              <motion.div 
                className="relative h-24 sm:h-28 md:h-32 bg-black rounded-xl overflow-hidden group cursor-pointer"
                style={{ boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}
                whileHover={prefersReducedMotion ? {} : { y: -4, boxShadow: '0 12px 30px rgba(236,72,153,0.15)' }}
                transition={{ duration: 0.3 }}
              >
                <img 
                  src={aiFingerImg} 
                  alt="AI-powered Instagram content creation - finger touching digital interface for social media marketing automation"
                  className="absolute inset-0 w-full h-full object-cover"
                  style={{ objectPosition: '75% 50%' }}
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                <div className="absolute bottom-1 left-1.5 right-1.5 flex items-center justify-between text-white">
                  <span className="text-[8px] sm:text-[9px] font-bold opacity-90">IG POST</span>
                  <span className="text-[10px] sm:text-xs font-black">2.4M</span>
                </div>
              </motion.div>
              
              {/* Card 2 - Video Campaign with Autoplay */}
              <motion.div 
                className="relative h-24 sm:h-28 md:h-32 bg-black rounded-xl overflow-hidden group cursor-pointer"
                style={{ boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}
                whileHover={prefersReducedMotion ? {} : { y: -4, boxShadow: '0 12px 30px rgba(139,92,246,0.15)' }}
                transition={{ duration: 0.3 }}
                aria-label="Video marketing campaign showcase - 8.7M+ views social media video content"
              >
                <video 
                  autoPlay 
                  loop 
                  muted 
                  playsInline
                  preload="auto"
                  className="absolute inset-0 w-full h-full object-cover"
                  src={heroVideo}
                  title="High-engagement social media video campaign for brand awareness and conversions"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-1 left-1.5 right-1.5 flex items-center justify-between text-white">
                  <span className="text-[8px] sm:text-[9px] font-bold opacity-90">VIDEO</span>
                  <span className="text-[10px] sm:text-xs font-black">8.7M+</span>
                </div>
              </motion.div>
              
              {/* Card 3 - TikTok with Autoplay Video */}
              <motion.div 
                className="relative h-24 sm:h-28 md:h-32 bg-black rounded-xl overflow-hidden group cursor-pointer"
                style={{ boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}
                whileHover={prefersReducedMotion ? {} : { y: -4, boxShadow: '0 12px 30px rgba(0,0,0,0.15)' }}
                transition={{ duration: 0.3 }}
                aria-label="Viral TikTok content creation - 5.2M views short-form video marketing"
              >
                <video 
                  autoPlay 
                  loop 
                  muted 
                  playsInline
                  preload="auto"
                  className="absolute inset-0 w-full h-full object-cover"
                  src={tiktokVideo}
                  title="TikTok viral marketing video - trending content for Gen Z audience engagement"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-1 left-1.5 right-1.5 flex items-center justify-between text-white">
                  <span className="text-[8px] sm:text-[9px] font-bold opacity-90">TIKTOK</span>
                  <span className="text-[10px] sm:text-xs font-black">5.2M</span>
                </div>
              </motion.div>
              
              {/* Card 4 - Ad ROAS */}
              <motion.div 
                className="relative h-24 sm:h-28 md:h-32 bg-white rounded-xl overflow-hidden group cursor-pointer"
                style={{ boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}
                whileHover={prefersReducedMotion ? {} : { y: -4, boxShadow: '0 12px 30px rgba(255,107,53,0.15)' }}
                transition={{ duration: 0.3 }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-[#FF6B35] to-[#F97316]" />
                <div className="absolute inset-0 flex flex-col items-center justify-center p-2 text-white">
                  <TrendingUp className="w-6 h-6 sm:w-7 sm:h-7 mb-1" />
                  <span className="text-[9px] sm:text-[10px] font-bold opacity-80">AD ROAS</span>
                  <span className="text-base sm:text-lg font-black">4.7x</span>
                </div>
              </motion.div>
              
              {/* Card 5 - Reels */}
              <motion.div 
                className="relative h-24 sm:h-28 md:h-32 bg-white rounded-xl overflow-hidden group cursor-pointer"
                style={{ boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}
                whileHover={prefersReducedMotion ? {} : { y: -4, boxShadow: '0 12px 30px rgba(16,185,129,0.15)' }}
                transition={{ duration: 0.3 }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-[#10B981] to-[#059669]" />
                <div className="absolute inset-0 flex flex-col items-center justify-center p-2 text-white">
                  <Camera className="w-6 h-6 sm:w-7 sm:h-7 mb-1" />
                  <span className="text-[9px] sm:text-[10px] font-bold opacity-80">REELS</span>
                  <span className="text-sm sm:text-base font-black">890K</span>
                </div>
              </motion.div>
              
              {/* Card 6 - LinkedIn with Professional Portrait */}
              <motion.div 
                className="relative h-24 sm:h-28 md:h-32 bg-black rounded-xl overflow-hidden group cursor-pointer"
                style={{ boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}
                whileHover={prefersReducedMotion ? {} : { y: -4, boxShadow: '0 12px 30px rgba(10,102,194,0.2)' }}
                transition={{ duration: 0.3 }}
              >
                <img 
                  src={linkedinPortraitImg}
                  alt="Professional LinkedIn thought leadership portrait - executive business headshot for B2B marketing"
                  className="absolute inset-0 w-full h-full object-cover object-top"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0077B5]/80 via-transparent to-transparent" />
                <div className="absolute bottom-1 left-1.5 right-1.5 flex items-center justify-between text-white">
                  <span className="text-[8px] sm:text-[9px] font-bold opacity-90">LINKEDIN</span>
                  <span className="text-[10px] sm:text-xs font-black">B2B</span>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* SERVICE CARDS - ELITE Four Pillars Section */}
      <section className="py-20 md:py-28 px-6 bg-[#0a0a14] relative overflow-hidden">
        {/* Premium Top Line for flow from hero */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        
        {/* Subtle Grid Background */}
        <div className="absolute inset-0 opacity-[0.02] motion-reduce:hidden">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSA2MCAwIEwgMCAwIDAgNjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjIpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')]" />
        </div>
        
        {/* Subtle Background Glows - Matching card colors */}
        <div className="absolute inset-0 motion-reduce:hidden">
          <div className="absolute top-20 left-1/4 w-80 h-80 bg-[#6b21a8]/6 rounded-full blur-[120px]" />
          <div className="absolute bottom-20 right-1/4 w-80 h-80 bg-[#047857]/6 rounded-full blur-[120px]" />
          <div className="absolute top-1/2 right-1/3 w-64 h-64 bg-[#831843]/5 rounded-full blur-[100px]" />
        </div>
        
        <div className="max-w-6xl mx-auto relative z-10">
          {/* Premium Header */}
          <motion.div 
            initial={fadeIn}
            whileInView={fadeInVisible}
            viewport={{ once: true }}
            className="text-center mb-16 md:mb-20"
          >
            {/* Elegant Badge */}
            <span className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/[0.03] backdrop-blur-sm rounded-full text-xs font-semibold text-white/50 mb-8 border border-white/[0.06] tracking-[0.2em] uppercase" style={{ fontFamily: 'Inter, system-ui, -apple-system, sans-serif' }}>
              <Layers className="w-3.5 h-3.5" />
              Our Services
            </span>
            
            {/* Premium Headline */}
            <h2 className="text-3xl md:text-5xl lg:text-6xl font-black text-white mb-4 tracking-tight" style={{ fontFamily: 'Inter, system-ui, -apple-system, sans-serif' }}>
              Four Pillars of
            </h2>
            <h2 className="text-3xl md:text-5xl lg:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#6b21a8] via-[#831843] to-[#c2410c]" style={{ fontFamily: 'Inter, system-ui, -apple-system, sans-serif' }}>
              Creative Growth
            </h2>
            
            {/* Subtle Subtitle */}
            <p className="mt-6 text-white/50 text-base md:text-lg max-w-xl mx-auto leading-relaxed" style={{ fontFamily: 'Inter, system-ui, -apple-system, sans-serif' }}>
              Strategic services designed to elevate your brand and drive measurable results
            </p>
          </motion.div>

          {/* ELITE Premium Card Grid - Image-Based */}
          <div className="grid md:grid-cols-2 gap-8 md:gap-10 max-w-[1200px] mx-auto">
            {pillarCards.map((card, idx) => (
              <PillarCard key={card.id} card={card} idx={idx} />
            ))}
          </div>
        </div>
      </section>

      {/* PORTFOLIO SHOWCASE - with navy undertones */}
      <section id="portfolio" className="py-24 px-6 bg-gradient-to-b from-[#0f0f23] via-[#151528] to-[#1a1a2e] relative overflow-hidden">
        {/* AI Neural Pattern Overlay for consistency */}
        <div className="absolute inset-0 opacity-10 motion-reduce:hidden">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0ibmV1cmFsIiB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PGNpcmNsZSBjeD0iNTAiIGN5PSI1MCIgcj0iMiIgZmlsbD0icmdiYSgxMjMsNDcsMjQ3LDAuNSkiLz48Y2lyY2xlIGN4PSIyMCIgY3k9IjIwIiByPSIxLjUiIGZpbGw9InJnYmEoMjU1LDEwNywxNTcsMC40KSIvPjxjaXJjbGUgY3g9IjgwIiBjeT0iMzAiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDEwNyw4MywwLjQpIi8+PGxpbmUgeDE9IjUwIiB5MT0iNTAiIHgyPSIyMCIgeTI9IjIwIiBzdHJva2U9InJnYmEoMTIzLDQ3LDI0NywwLjIpIiBzdHJva2Utd2lkdGg9IjAuNSIvPjxsaW5lIHgxPSI1MCIgeTE9IjUwIiB4Mj0iODAiIHkyPSIzMCIgc3Ryb2tlPSJyZ2JhKDI1NSwxMDcsMTU3LDAuMikiIHN0cm9rZS13aWR0aD0iMC41Ii8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI25ldXJhbCkiLz48L3N2Zz4=')]" />
        </div>
        <div className="absolute inset-0 motion-reduce:hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-[#7B2FF7]/15 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-[#FF6B9D]/15 rounded-full blur-3xl" />
        </div>
        
        <div className="max-w-6xl mx-auto relative z-10">
          <motion.div 
            initial={fadeIn}
            whileInView={fadeInVisible}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full text-sm font-semibold text-white/60 mb-6 border border-white/10">
              <Camera className="w-4 h-4" />
              Our Work
            </span>
            <h2 className="text-4xl md:text-6xl font-black text-white mb-6">
              See What We <br/>
              <span className="text-white">
                Create
              </span>
            </h2>
            <p className="text-lg text-zinc-400 max-w-2xl mx-auto">
              Real campaigns. Real results. Content engineered to outperform.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {portfolioItems.map((item, idx) => (
              <CreativePortfolioCard key={idx} {...item} delay={idx * 0.1} />
            ))}
          </div>
          
          <motion.div 
            initial={fadeIn}
            whileInView={fadeInVisible}
            viewport={{ once: true }}
            className="text-center mt-12"
          >
            <Link href="/our-work">
              <motion.button
                whileHover={prefersReducedMotion ? {} : { scale: 1.05 }}
                className="inline-flex items-center gap-2 bg-white text-zinc-900 rounded-full px-8 py-4 font-bold shadow-xl hover:shadow-2xl transition-all"
                data-testid="button-view-all-work"
              >
                View All Projects
                <ArrowRight className="w-5 h-5" />
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Platform Mastery */}
      <section className="py-20 px-6 bg-zinc-900">
        <div className="max-w-6xl mx-auto">
          <motion.div 
            initial={fadeIn}
            whileInView={fadeInVisible}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-black text-white mb-4">
              Platform Mastery
            </h2>
            <p className="text-zinc-400 text-lg">
              Direct API integrations and certified partnerships
            </p>
          </motion.div>
          
          <div className="flex justify-center items-center gap-6 md:gap-10 flex-wrap">
            {platformIcons.map((platform, idx) => (
              <motion.div 
                key={idx}
                initial={prefersReducedMotion ? {} : { opacity: 0, scale: 0.8 }}
                whileInView={prefersReducedMotion ? {} : { opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={prefersReducedMotion ? {} : { delay: idx * 0.05 }}
                whileHover={prefersReducedMotion ? {} : { scale: 1.3, y: -8 }}
                className="w-16 h-16 md:w-20 md:h-20 bg-white rounded-2xl flex items-center justify-center shadow-xl hover:shadow-2xl transition-all cursor-pointer"
                data-testid={`icon-platform-${idx}`}
                title={platform.label}
              >
                <platform.Icon 
                  className="h-8 w-8 md:h-10 md:w-10" 
                  style={{ color: platform.color }}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Industries Section - Navy undertones for consistency */}
      <section className="py-24 px-6 bg-gradient-to-b from-[#1a1a2e] via-[#0f0f23] to-[#151528] relative overflow-hidden">
        {/* AI Circuit Pattern */}
        <div className="absolute inset-0 opacity-5 motion-reduce:hidden">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iY2lyY3VpdCIgd2lkdGg9IjIwMCIgaGVpZ2h0PSIyMDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiPjxwYXRoIGQ9Ik0wIDUwIEg4MCBWMTBIMTI1IFY1MCBIMjAwIiBmaWxsPSJub25lIiBzdHJva2U9InJnYmEoMTIzLDQ3LDI0NywwLjMpIiBzdHJva2Utd2lkdGg9IjEiLz48cGF0aCBkPSJNMCAxNTAgSDUwIFYxMDAgSDEwMCBWMTUwIEgyMDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMTA3LDE1NywwLjMpIiBzdHJva2Utd2lkdGg9IjEiLz48Y2lyY2xlIGN4PSI4MCIgY3k9IjUwIiByPSI0IiBmaWxsPSJyZ2JhKDEyMyw0NywyNDcsMC41KSIvPjxjaXJjbGUgY3g9IjEyNSIgY3k9IjEwIiByPSIzIiBmaWxsPSJyZ2JhKDI1NSwxMDcsMTU3LDAuNSkiLz48Y2lyY2xlIGN4PSI1MCIgY3k9IjE1MCIgcj0iNCIgZmlsbD0icmdiYSgyNTUsMTA3LDgzLDAuNSkiLz48Y2lyY2xlIGN4PSIxMDAiIGN5PSIxMDAiIHI9IjMiIGZpbGw9InJnYmEoMTIzLDQ3LDI0NywwLjUpIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2NpcmN1aXQpIi8+PC9zdmc+')]" />
        </div>
        <div className="max-w-6xl mx-auto relative z-10">
          <motion.div 
            initial={fadeIn}
            whileInView={fadeInVisible}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full text-sm font-semibold text-white/60 mb-6 border border-white/10">
              <Target className="w-4 h-4" />
              Industries We Transform
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
              Built for <span className="text-white">Category Leaders</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {useCases.map((useCase, idx) => (
              <motion.div 
                key={useCase.id}
                initial={prefersReducedMotion ? {} : { opacity: 0, y: 30 }}
                whileInView={prefersReducedMotion ? {} : { opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={prefersReducedMotion ? {} : { delay: idx * 0.08 }}
                whileHover={prefersReducedMotion ? {} : { y: -5, scale: 1.02 }}
                className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:border-white/20 transition-all duration-300 group" 
                data-testid={`use-case-${useCase.id}`}
              >
                <div className={`h-2 w-20 bg-gradient-to-r ${useCase.color} rounded-full mb-6 group-hover:w-full transition-all duration-500`} />
                <h3 className="text-xl font-bold mb-3 text-white">{useCase.title}</h3>
                <p className="text-zinc-400 mb-4">
                  {useCase.description}
                </p>
                <ul className="space-y-2 text-sm">
                  {useCase.points.map((point, i) => (
                    <li key={i} className="flex items-center gap-2 text-white/70">
                      <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${useCase.color}`} />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trusted Brands - Dark theme */}
      <section className="py-16 px-6 bg-[#0f0f23]">
        <div className="max-w-6xl mx-auto">
          <motion.p 
            initial={fadeIn}
            whileInView={fadeInVisible}
            viewport={{ once: true }}
            className="text-center text-lg text-zinc-400 mb-8"
          >
            Trusted by brands scaling from startup to enterprise
          </motion.p>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-8 items-center justify-items-center">
            {brandLogos.map((logo, i) => (
              <motion.div 
                key={i}
                initial={prefersReducedMotion ? {} : { opacity: 0, scale: 0.9 }}
                whileInView={prefersReducedMotion ? {} : { opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={prefersReducedMotion ? {} : { delay: i * 0.05 }}
                whileHover={prefersReducedMotion ? {} : { scale: 1.1 }}
                className="h-16 w-24 flex items-center justify-center" 
                data-testid={`brand-${i + 1}`}
              >
                <img 
                  src={logo}
                  alt={`Brand ${i + 1}`}
                  className="max-h-full w-auto object-contain grayscale hover:grayscale-0 transition-all duration-300"
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA - Vibrant Gradient */}
      <section className="py-24 px-6 bg-gradient-to-br from-[#7B2FF7] via-[#FF6B9D] to-[#FF6B53] relative overflow-hidden">
        {/* Decorative Elements */}
        <motion.div 
          className="absolute top-10 left-10 w-40 h-40 bg-yellow-300/30 rounded-full blur-3xl motion-reduce:hidden"
          animate={prefersReducedMotion ? {} : { scale: [1, 1.3, 1] }}
          transition={prefersReducedMotion ? {} : { duration: 5, repeat: Infinity }}
        ></motion.div>
        <motion.div 
          className="absolute bottom-10 right-10 w-60 h-60 bg-[#23AACA]/30 rounded-full blur-3xl motion-reduce:hidden"
          animate={prefersReducedMotion ? {} : { scale: [1.3, 1, 1.3] }}
          transition={prefersReducedMotion ? {} : { duration: 7, repeat: Infinity }}
        ></motion.div>
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div
            initial={fadeIn}
            whileInView={fadeInVisible}
            viewport={{ once: true }}
          >
            <span className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-sm font-bold text-white mb-8 border border-white/30">
              <Rocket className="w-4 h-4" />
              Ready to Scale?
            </span>
            
            <h2 className="text-4xl md:text-6xl lg:text-7xl font-black text-white mb-6 leading-[1.1]">
              Let's Create
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#c4ff4d] to-[#23AACA]">
                Something Amazing
              </span>
            </h2>
            
            <p className="text-xl text-white/80 mb-12 max-w-2xl mx-auto">
              Book a strategy call with our Malta-based team. We'll show you exactly how OARC can accelerate your creative and revenue.
            </p>
            
            <Link href="/contact">
              <MagneticButton
                whileHover={prefersReducedMotion ? {} : { scale: 1.05 }}
                whileTap={prefersReducedMotion ? {} : { scale: 0.98 }}
                className="group inline-flex items-center gap-3 bg-white text-[#1a2e29] rounded-full px-10 py-5 text-xl font-bold shadow-2xl hover:shadow-[0_25px_50px_rgba(255,255,255,0.3)] transition-all"
                data-testid="button-final-cta"
              >
                Book Strategy Call
                <div className="w-12 h-12 bg-gradient-to-br from-[#7B2FF7] to-[#FF6B9D] rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform">
                  <ArrowRight className="h-6 w-6 text-white" />
                </div>
              </MagneticButton>
            </Link>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
