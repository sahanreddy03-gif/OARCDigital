import fs from 'fs';
import path from 'path';
import sharp from 'sharp';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configuration
const TARGET_DIR = path.join(__dirname, '../client/src');
const QUALITY_PNG = 80;
const QUALITY_JPG = 80;

async function getAllFiles(dirPath, arrayOfFiles) {
    const files = fs.readdirSync(dirPath);

    arrayOfFiles = arrayOfFiles || [];

    files.forEach(function (file) {
        if (fs.statSync(dirPath + "/" + file).isDirectory()) {
            arrayOfFiles = getAllFiles(dirPath + "/" + file, arrayOfFiles);
        } else {
            arrayOfFiles.push(path.join(dirPath, "/", file));
        }
    });

    return arrayOfFiles;
}

async function optimizeImages() {
    console.log('🚀 Starting Image Optimization...');

    try {
        const allFiles = await getAllFiles(TARGET_DIR);
        const imageFiles = allFiles.filter(file =>
            file.match(/\.(png|jpg|jpeg)$/i)
        );

        console.log(`📸 Found ${imageFiles.length} images to process.`);

        let savedBytes = 0;

        for (const file of imageFiles) {
            const ext = path.extname(file).toLowerCase();
            const originalStats = fs.statSync(file);
            const originalSize = originalStats.size;

            let pipeline;
            if (ext === '.png') {
                pipeline = sharp(file).png({ quality: QUALITY_PNG, compressionLevel: 9, palette: true });
            } else if (ext === '.jpg' || ext === '.jpeg') {
                pipeline = sharp(file).jpeg({ quality: QUALITY_JPG, mozjpeg: true });
            }

            if (pipeline) {
                // Process to buffer first to avoid file lock issues
                const buffer = await pipeline.toBuffer();
                fs.writeFileSync(file, buffer);

                const newSize = buffer.length;
                const saving = originalSize - newSize;
                savedBytes += saving;

                if (saving > 0) {
                    console.log(`✅ Optimized: ${path.basename(file)} | Saved: ${(saving / 1024).toFixed(2)} KB`);
                } else {
                    console.log(`⏭️  Skipped: ${path.basename(file)} (Already optimized)`);
                }
            }
        }

        console.log(`\n🎉 Optimization Complete! Total Space Saved: ${(savedBytes / 1024 / 1024).toFixed(2)} MB`);
        console.log('NOTE: If you expected more reduction, try converting to WebP (requires code changes).');

    } catch (error) {
        console.error('❌ Error during optimization:', error);
    }
}

optimizeImages();
