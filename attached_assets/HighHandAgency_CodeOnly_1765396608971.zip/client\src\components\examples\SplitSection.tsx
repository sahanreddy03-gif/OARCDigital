import SplitSection from '../SplitSection';

export default function SplitSectionExample() {
  return <SplitSection />;
}
