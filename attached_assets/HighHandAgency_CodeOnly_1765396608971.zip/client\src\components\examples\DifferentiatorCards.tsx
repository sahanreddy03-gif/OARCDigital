import DifferentiatorCards from '../DifferentiatorCards';

export default function DifferentiatorCardsExample() {
  return <DifferentiatorCards />;
}
