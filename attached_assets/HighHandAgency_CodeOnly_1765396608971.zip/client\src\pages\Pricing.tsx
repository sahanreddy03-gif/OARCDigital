import { useState } from 'react';
import Layout from "@/components/layout/Layout";
import SEOHead from "@/components/SEOHead";
import { supportingPagesSEO } from "@/data/seoMetadata";
import { Button } from "@/components/ui/button";
import { Check, Star, Building2, Zap, Sparkles, Crown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'wouter';

const pricingCategories = [
  {
    id: 'social',
    label: 'Social Creative',
    accent: 'text-lime-600',
    bg: 'bg-lime-500',
    gradient: 'from-lime-400 to-green-500',
    lightBg: 'bg-lime-50'
  },
  {
    id: 'web',
    label: 'Web Experience',
    accent: 'text-orange-600',
    bg: 'bg-orange-500',
    gradient: 'from-orange-400 to-amber-500',
    lightBg: 'bg-orange-50'
  },
  {
    id: 'ai',
    label: 'AI Employees',
    accent: 'text-blue-600',
    bg: 'bg-blue-600',
    gradient: 'from-blue-500 to-indigo-600',
    lightBg: 'bg-blue-50'
  }
];

const sharedFeatures = [
  "Dedicated creative project manager",
  "Turnaround times starting at 48 hours",
  "Global timezone coverage",
  "AI-enhanced workflows",
  "Unlimited revisions on all drafts",
  "Support for multiple brands",
  "Real-time revenue dashboard"
];

const pricingData = {
  social: [
    {
      name: "STARTER",
      price: "299",
      period: "/month",
      desc: "Essentials for early-stage branding.",
      sub: "€10/day equivalent",
      features: ["16 High-Fidelity Posts", "1 Platform", "Custom Design System", "Monthly Analytics"],
      icon: Sparkles,
      style: "basic",
      cta: "Start Basic"
    },
    {
      name: "GROWTH",
      price: "549",
      period: "/month",
      desc: "Accelerated output for scaling teams.",
      sub: "Best Value",
      features: ["24 High-Fidelity Posts", "2 Platforms", "4 Short-Form Videos", "Community Management"],
      icon: Zap,
      style: "popular",
      cta: "Accelerate Growth"
    },
    {
      name: "SCALE",
      price: "895",
      period: "/month",
      desc: "Maximum dominance & daily volume.",
      sub: "Enterprise Grade",
      features: ["Daily Posting (32/mo)", "All Platforms", "2 Cinematic Videos", "Influencer Outreach"],
      icon: Crown,
      style: "premium",
      cta: "Dominate Market"
    }
  ],
  web: [
    { name: "ESSENTIALS", price: "995", period: "one-time", desc: "Professional landing page system.", sub: "+€49/mo hosting", features: ["5 Pages", "Contact Form", "Basic SEO"], icon: Sparkles, style: "basic", cta: "Build Site" },
    { name: "GROWTH", price: "1,995", period: "one-time", desc: "Conversion-focused growth engine.", sub: "Best Value", features: ["10 Pages", "CMS Setup", "Booking System"], icon: Zap, style: "popular", cta: "Build Platform" },
    { name: "E-COMMERCE", price: "3,995", period: "one-time", desc: "Full-scale digital retail storefront.", sub: "Enterprise Grade", features: ["50 Products", "Payments", "Inventory Logic"], icon: Crown, style: "premium", cta: "Launch Store" }
  ],
  ai: [
    { name: "ASSISTANT", price: "1,495", period: "setup", desc: "24/7 Customer support agent.", sub: "+€149/mo maintain", features: ["Chatbot", "Lead Capture", "100 FAQs"], icon: Sparkles, style: "basic", cta: "Deploy AI" },
    { name: "WORKFLOW", price: "2,995", period: "setup", desc: "Automate core business ops.", sub: "Best Value", features: ["3 Workflows", "CRM Sync", "Email Bots"], icon: Zap, style: "popular", cta: "Automate" },
    { name: "CUSTOM", price: "Custom", period: "", desc: "Tailored enterprise solutions.", sub: "Scope Dependent", features: ["Full Department", "Custom LLMs", "API Dev"], icon: Crown, style: "premium", cta: "Book Call" }
  ]
};

const AnimatedBackground = () => (
  <div className="absolute inset-0 overflow-hidden pointer-events-none">
    <motion.div
      animate={{
        scale: [1, 1.2, 1],
        opacity: [0.3, 0.5, 0.3],
        x: [0, 50, 0],
        y: [0, -50, 0]
      }}
      transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
      className="absolute top-[-10%] left-[-10%] w-[800px] h-[800px] bg-lime-200/40 rounded-full blur-[120px]"
    />
    <motion.div
      animate={{
        scale: [1, 1.3, 1],
        opacity: [0.2, 0.4, 0.2],
        x: [0, -30, 0]
      }}
      transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 2 }}
      className="absolute top-[20%] right-[-10%] w-[600px] h-[600px] bg-blue-200/40 rounded-full blur-[100px]"
    />
    <motion.div
      animate={{
        scale: [1, 1.1, 1],
        opacity: [0.2, 0.4, 0.2],
        y: [0, 40, 0]
      }}
      transition={{ duration: 18, repeat: Infinity, ease: "easeInOut", delay: 5 }}
      className="absolute bottom-[-10%] left-[20%] w-[700px] h-[700px] bg-orange-200/40 rounded-full blur-[120px]"
    />
  </div>
);

export default function Pricing() {
  const [activeTab, setActiveTab] = useState<'social' | 'web' | 'ai'>('social');
  const activeTheme = pricingCategories.find(c => c.id === activeTab) || pricingCategories[0];

  return (
    <Layout>
      <SEOHead
        title="Pricing Plans | OARC Digital"
        description="Flexible plans built for growth. Choose your subscription."
        canonicalUrl={`https://oarcdigital.com${supportingPagesSEO.pricing.path}`}
        ogType={supportingPagesSEO.pricing.ogType}
      />

      <div className="min-h-screen bg-slate-50/50 font-sans text-slate-900 pt-32 pb-24 relative">
        <AnimatedBackground />

        {/* --- HERO HEADER --- */}
        <div className="container mx-auto px-6 max-w-7xl mb-16 text-center relative z-10">
          <h1 className="text-5xl md:text-7xl font-serif font-medium tracking-tight mb-4 text-slate-900">
            A subscription built to <br />
            <span className={`italic text-transparent bg-clip-text bg-gradient-to-r ${activeTheme.gradient}`}>
              fuel your growth
            </span>
          </h1>
        </div>

        {/* --- SUPERSIDE SPLIT LAYOUT --- */}
        <div className="container mx-auto px-6 max-w-7xl mb-24 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 min-h-[500px]">

            {/* LEFT: Visually Rich Card */}
            <div className="relative rounded-[2.5rem] overflow-hidden p-10 md:p-16 flex flex-col justify-center bg-white shadow-2xl shadow-slate-200/50">
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop')] bg-cover bg-center opacity-30 mix-blend-overlay" />
              {/* Animated Gradient Overlay */}
              <div className={`absolute inset-0 opacity-10 bg-gradient-to-br ${activeTheme.gradient}`} />

              <div className="relative z-10 max-w-lg">
                <div className="inline-flex items-center gap-2 mb-6 px-4 py-2 bg-slate-900 text-white rounded-full text-xs font-bold uppercase tracking-widest">
                  <Star className="w-3 h-3 text-yellow-400 fill-current" /> Founding Client Special
                </div>
                <h2 className="text-4xl md:text-5xl font-serif font-medium mb-6 leading-tight text-slate-900">
                  Flexible plans <br />
                  <span className="italic text-slate-500">for every stage.</span>
                </h2>
                <p className="text-lg text-slate-600 mb-10 leading-relaxed font-medium">
                  Lock in your founding rate instantly.
                  From asset production to full-scale AI automation, we move
                  <span className="text-slate-900 font-bold"> 10x faster</span> than traditional agencies.
                </p>
                <Link href="/contact">
                  <Button className="h-14 px-10 rounded-full bg-slate-900 text-white font-bold text-base hover:bg-black transition-all hover:scale-105 shadow-xl hover:shadow-2xl">
                    Book Strategy Call
                  </Button>
                </Link>
              </div>
            </div>

            {/* RIGHT: Feature Checklist (Dynamic Color) */}
            <div className={`relative rounded-[2.5rem] overflow-hidden p-10 md:p-16 flex flex-col justify-center transition-colors duration-500 ${activeTheme.bg}`}>
              {/* Interior Glow */}
              <div className="absolute inset-0 bg-white/10 mix-blend-overlay" />
              <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-white/20 blur-[80px] rounded-full" />

              <h3 className="relative z-10 text-3xl font-serif font-medium mb-10 text-slate-900 mix-blend-color-burn">
                Included in <span className="italic">all plans:</span>
              </h3>
              <div className="relative z-10 space-y-5">
                {sharedFeatures.map((item, i) => (
                  <div key={i} className="flex items-start gap-4 group">
                    <div className="p-1 rounded-full bg-black/5 group-hover:bg-black/10 transition-colors">
                      <Check className="w-4 h-4 text-slate-900 stroke-[3]" />
                    </div>
                    <span className="text-base font-bold text-slate-900/90 leading-snug">
                      {item}
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>

        {/* --- TIER SELECTION --- */}
        <div className="container mx-auto px-6 max-w-7xl relative z-10">

          <div className="flex justify-center mb-16">
            <div className="inline-flex bg-white/80 backdrop-blur-md p-2 rounded-full border border-slate-200 shadow-lg">
              {pricingCategories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setActiveTab(cat.id as 'social' | 'web' | 'ai')}
                  className={`px-8 py-3 rounded-full text-sm font-bold transition-all ${activeTab === cat.id
                      ? `bg-slate-900 text-white shadow-md`
                      : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  data-testid={`tab-${cat.id}`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* --- PRICING CARDS --- */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-32 items-start">
            <AnimatePresence mode="wait">
              {pricingData[activeTab].map((plan, i) => {
                const Icon = plan.icon;

                const isBasic = plan.style === 'basic';
                const isPopular = plan.style === 'popular';
                const isPremium = plan.style === 'premium';

                return (
                  <motion.div
                    key={plan.name}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1, type: "spring", stiffness: 100 }}
                    className={`group relative p-8 rounded-[2rem] flex flex-col transition-all duration-300
                                    ${isBasic ? 'bg-white border border-slate-200 shadow-lg hover:shadow-xl' : ''}
                                    ${isPopular ? 'bg-white border-2 border-slate-900 shadow-2xl scale-[1.05] z-10' : ''}
                                    ${isPremium ? 'bg-slate-900 text-white shadow-2xl hover:translate-y-[-8px]' : ''}
                                `}
                    data-testid={`card-${plan.name.toLowerCase()}`}
                  >
                    {isPopular && (
                      <div className={`absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest shadow-lg ${activeTheme.bg} text-slate-900`}>
                        Most Popular
                      </div>
                    )}

                    {/* Card Header */}
                    <div className="mb-8 flex items-start justify-between gap-2">
                      <div className={`p-3 rounded-2xl ${isPremium ? 'bg-white/10' : activeTheme.lightBg}`}>
                        <Icon className={`w-6 h-6 ${isPremium ? 'text-white' : activeTheme.accent}`} />
                      </div>
                      {isPremium && <Crown className="w-5 h-5 text-yellow-400 fill-current" />}
                    </div>

                    <div className="mb-6">
                      <h3 className={`text-2xl font-black mb-2 ${isPremium ? 'text-white' : 'text-slate-900'}`}>{plan.name}</h3>
                      <p className={`text-sm leading-relaxed min-h-[40px] ${isPremium ? 'text-slate-400' : 'text-slate-500'}`}>{plan.desc}</p>
                    </div>

                    {/* Price Block */}
                    <div className={`mb-8 p-6 rounded-2xl text-center ${isPremium ? 'bg-white/5 border border-white/10' : 'bg-slate-50 border border-slate-100'}`}>
                      <div className={`flex items-center justify-center gap-1 ${isPremium ? 'text-white' : 'text-slate-900'}`}>
                        <span className="text-sm font-bold">€</span>
                        <span className="text-5xl font-black tracking-tighter">{plan.price}</span>
                      </div>
                      <div className={`text-[10px] font-bold uppercase tracking-wider mt-2 ${isPremium ? 'text-slate-500' : 'text-slate-400'}`}>{plan.period}</div>
                      {plan.sub && <div className={`text-xs mt-2 font-bold ${isPremium ? 'text-lime-400' : activeTheme.accent}`}>{plan.sub}</div>}
                    </div>

                    {/* Features */}
                    <div className="flex-grow space-y-4 mb-10">
                      {plan.features.map((feat: string) => (
                        <div key={feat} className="flex items-center gap-3 text-sm font-medium">
                          <div className={`w-1.5 h-1.5 rounded-full ${isPremium ? 'bg-lime-400' : 'bg-slate-300 group-hover:bg-slate-900'}`} />
                          <span className={isPremium ? 'text-slate-200' : 'text-slate-700'}>{feat}</span>
                        </div>
                      ))}
                    </div>

                    <Button className={`w-full h-14 rounded-full font-bold text-base transition-all ${isPopular
                        ? `bg-slate-900 text-white hover:bg-black shadow-lg`
                        : isPremium
                          ? 'bg-white text-black hover:bg-slate-100'
                          : 'bg-white border-2 border-slate-200 text-slate-900 hover:border-slate-900'
                      }`}
                      data-testid={`button-${plan.name.toLowerCase()}`}
                    >
                      {plan.cta}
                    </Button>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>

          {/* --- ENTERPRISE SECTION --- */}
          <div className="rounded-[2.5rem] bg-slate-900 text-white p-10 md:p-20 relative overflow-hidden shadow-2xl">
            {/* Abstract Pattern */}
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10" />
            <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gradient-to-br from-blue-600 to-lime-500 opacity-20 blur-[120px] rounded-full translate-x-1/3 -translate-y-1/3" />

            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="flex items-center gap-2 mb-6 text-lime-400 text-xs font-bold uppercase tracking-widest">
                  <Building2 className="w-4 h-4" /> Enterprise
                </div>
                <h2 className="text-4xl md:text-5xl font-serif font-medium mb-6 leading-tight">
                  Need a custom <br />
                  <span className="italic text-slate-400">enterprise solution?</span>
                </h2>
                <ul className="space-y-4 mb-10">
                  {[
                    "Dedicated creative teams (no shared resources)",
                    "Custom AI model training on your brand data",
                    "SLA-backed delivery guarantees",
                    "Single Sign-On (SSO) & Advanced Security"
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-slate-300 font-medium">
                      <Check className="w-5 h-5 text-lime-400" />
                      {item}
                    </li>
                  ))}
                </ul>
                <Link href="/contact">
                  <Button 
                    className="h-14 px-8 rounded-full bg-white text-black font-bold hover:bg-slate-200 transition-colors shadow-lg"
                    data-testid="button-enterprise"
                  >
                    Talk to Sales
                  </Button>
                </Link>
              </div>
            </div>
          </div>

        </div>
      </div>
    </Layout>
  );
}
