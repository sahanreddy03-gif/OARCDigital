import BrandLogos from '../BrandLogos';

export default function BrandLogosExample() {
  return <BrandLogos />;
}
