import PhoneMockup from '../PhoneMockup';

export default function PhoneMockupExample() {
  return (
    <div className="p-12 bg-muted">
      <PhoneMockup />
    </div>
  );
}
