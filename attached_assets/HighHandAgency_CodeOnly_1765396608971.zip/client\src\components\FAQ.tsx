import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "How do AI Employees work?",
    answer: "Our AI Employees are trained on your business processes and data to handle specific tasks like customer support, lead qualification, and administrative work. They integrate seamlessly with your existing tools and learn from each interaction to improve over time.",
  },
  {
    question: "What's included in the AI Creative service?",
    answer: "AI Creative includes video production, social media content, motion graphics, brand imagery, character design, voice generation, and website design. We combine AI technology with human oversight to ensure quality and brand alignment.",
  },
  {
    question: "How quickly can we see results?",
    answer: "Most clients see measurable improvements within 45-90 days. Initial setup and strategy development typically takes 2-3 weeks, followed by campaign launch and optimization. ROI varies by service but averages 68% within 8-12 months.",
  },
  {
    question: "Do you work with small businesses?",
    answer: "Yes! We work with businesses of all sizes. Our AI-powered approach allows us to deliver enterprise-level results at costs that work for growing companies. We offer flexible packages tailored to your budget and goals.",
  },
  {
    question: "What makes OARC different from other agencies?",
    answer: "We combine AI-certified talent, custom AI workflows, and guaranteed results. Unlike traditional agencies, we leverage AI to deliver faster, more cost-effective solutions without sacrificing quality. Our revenue-focused approach ensures every campaign drives measurable business outcomes.",
  },
  {
    question: "Can we customize the services to our needs?",
    answer: "Absolutely. Every engagement is customized to your specific goals, industry, and audience. We start with a discovery session to understand your needs, then build a tailored strategy using the right mix of our services.",
  },
];

export default function FAQ() {
  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="max-w-4xl mx-auto px-6 md:px-12">
        <div className="text-center mb-12 md:mb-16">
          <p className="text-sm text-muted-foreground italic mb-3">
            Because transparency is part of our process.
          </p>
          <p className="text-xs uppercase tracking-wider font-bold text-primary mb-4">
            Frequently Asked Questions
          </p>
          <h2 className="font-bold font-display mb-4" style={{ fontSize: 'clamp(2rem, 6vw, 4rem)', letterSpacing: '-0.03em', lineHeight: '1.15' }}>
            Questions from our <span className="italic font-bold">clients & partners</span>
          </h2>
          <p className="text-base text-muted-foreground">
            Everything you need to know about working with OARC Digital
          </p>
        </div>

        <Accordion type="single" collapsible className="w-full space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem 
              key={index} 
              value={`item-${index}`} 
              data-testid={`faq-item-${index}`}
              className="border border-border/50 rounded-lg px-6 hover-elevate hover:border-primary/60 hover:shadow-[0_0_15px_rgba(0,255,156,0.15)] transition-all duration-300"
            >
              <AccordionTrigger className="text-left text-base md:text-lg font-bold hover:no-underline py-4">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed pb-4">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
