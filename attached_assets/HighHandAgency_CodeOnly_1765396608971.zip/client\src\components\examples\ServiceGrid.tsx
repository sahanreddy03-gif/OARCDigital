import ServiceGrid from '../ServiceGrid';

export default function ServiceGridExample() {
  return <ServiceGrid />;
}
