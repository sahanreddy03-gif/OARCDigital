import FloatingChipCarousel from '../FloatingChipCarousel';

export default function FloatingChipCarouselExample() {
  return <FloatingChipCarousel />;
}
